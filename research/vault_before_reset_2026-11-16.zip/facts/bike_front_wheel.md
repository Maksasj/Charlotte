# bike_front_wheel

```datalog
turn(bike_front_wheel, same_way_as_lean). @from 2026-11-16T20:27:38 @conf 1 @source teacher:chat
causes(bike_front_wheel, bike_upright). @from 2026-11-16T20:27:55 @conf 1 @source teacher:chat
```
