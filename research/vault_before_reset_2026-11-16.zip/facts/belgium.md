# belgium

```datalog
proper_name(belgium). @from 2026-11-16T20:26:25 @conf 1 @source parser
```
