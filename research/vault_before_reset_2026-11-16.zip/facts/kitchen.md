# kitchen

```datalog
is_a(kitchen, room). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:48:54
has(kitchen, fridge). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:20:45
has(kitchen, oven). @from 2026-11-16T19:20:22 @conf 1 @source teacher:pretrain
has(kitchen, table). @from 2026-11-16T19:23:54 @conf 1 @source teacher:pretrain
```
