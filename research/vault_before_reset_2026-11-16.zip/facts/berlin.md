# berlin

```datalog
proper_name(berlin). @from 2026-11-16T19:15:02 @conf 1 @source parser
located_in(berlin, germany). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
is_a(berlin, city_in_germany). @from 2026-11-16T19:20:31 @conf 1 @source teacher:pretrain
is_a(berlin, capital_city). @from 2026-11-16T19:47:12 @conf 1 @source teacher:pretrain
capital_of(berlin, germany). @from 2026-11-16T19:47:12 @conf 1 @source teacher:pretrain
is_a(berlin, big_city). @from 2026-11-16T19:47:12 @conf 1 @source teacher:pretrain
```
