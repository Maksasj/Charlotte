# rainy

```datalog
is_a(rainy, weather). @from 2026-11-16T20:01:34 @conf 1 @source teacher:pretrain
proper_name(rainy). @from 2026-11-16T20:23:02 @conf 1 @source parser
```
