# many

```datalog
proper_name(many). @from 2026-11-16T19:20:17 @conf 1 @source parser
```
