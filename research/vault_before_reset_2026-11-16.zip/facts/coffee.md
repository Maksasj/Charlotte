# coffee

```datalog
property(coffee, taste, bitter). @from 2026-11-16T19:15:25 @conf 1 @source teacher:pretrain
proper_name(coffee). @from 2026-11-16T19:20:06 @conf 1 @source parser
is_a(coffee, drink). @from 2026-11-16T19:20:06 @conf 1 @source teacher:pretrain
is_a(coffee, breakfast_drink). @from 2026-11-16T19:20:50 @conf 1 @source teacher:pretrain
```
