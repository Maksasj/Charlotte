# axle_nut

```datalog
hold(axle_nut, wheel). @from 2026-11-16T21:09:18 @conf 1 @source teacher:train
```
