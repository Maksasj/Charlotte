# milky_way

```datalog
proper_name(milky_way). @from 2026-11-16T19:57:20 @conf 1 @source parser
is_a(milky_way, galaxy). @from 2026-11-16T19:57:26 @conf 1 @source teacher:pretrain
is_a(milky_way, spiral_galaxy). @from 2026-11-16T19:58:03 @conf 1 @source teacher:pretrain
```
