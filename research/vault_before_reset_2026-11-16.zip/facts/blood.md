# blood

```datalog
proper_name(blood). @from 2026-11-16T19:17:23 @conf 1 @source parser
property(blood, colour, red). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:30:42
located_in(blood, animal). @from 2026-11-16T19:18:46 @conf 1 @source teacher:pretrain
carry(blood, oxygen_through_body). @from 2026-11-16T19:26 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T20:29:25
move_through(blood, your_body). @from 2026-11-16T19:26:25 @conf 1 @source teacher:pretrain
carry(blood, oxygen). @from 2026-11-16T19:26:31 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T20:29:25
reach(blood, leg). @from 2026-11-16T20:29:24 @conf 1 @source teacher:chat
carry(blood, carbon_dioxide). @from 2026-11-16T20:31:24 @conf 1 @source teacher:chat
carry_to(blood, heart). @from 2026-11-16T20:31:24 @conf 1 @source teacher:chat
carry_to(blood, lung). @from 2026-11-16T20:31:24 @conf 1 @source teacher:chat
```
