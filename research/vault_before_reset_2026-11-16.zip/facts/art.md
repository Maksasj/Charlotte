# art

```datalog
proper_name(art). @from 2026-11-16T19:25:05 @conf 1 @source parser
is_a(art, school_subject). @from 2026-11-16T19:25:05 @conf 1 @source teacher:pretrain
```
