# peel

```datalog
part_of(peel, banana). @from 2026-11-16T19:15:25 @conf 1 @source teacher:pretrain
```
