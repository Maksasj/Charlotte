# its

```datalog
proper_name(its). @from 2026-11-16T20:29:22 @conf 1 @source parser
```
