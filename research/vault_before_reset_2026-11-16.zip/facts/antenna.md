# antenna

```datalog
is_a(antenna, feeler). @from 2026-11-16T19:43:47 @conf 1 @source teacher:pretrain
part_of(antenna, head). @from 2026-11-16T19:43:47 @conf 1 @source teacher:pretrain
part_of(antenna, insect_head). @from 2026-11-16T19:45:21 @conf 1 @source teacher:pretrain
```
