# feather

```datalog
help(feather, fly). @from 2026-11-16T19:38:58 @conf 1 @source teacher:pretrain @uses 5 @last 2026-11-16T19:45:41
help(feather, bird). @from 2026-11-16T19:39:48 @conf 1 @source teacher:pretrain @uses 5 @last 2026-11-16T19:45:41
keep_warm(feather, bird). @from 2026-11-16T19:39:48 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:43:15
```
