# pumpkin

```datalog
property(pumpkin, colour, orange). @from 2026-11-16T19:22:51 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:53:38
proper_name(pumpkin). @from 2026-11-16T19:47:57 @conf 1 @source parser
grow_on(pumpkin, vine). @from 2026-11-16T19:48:03 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:52:49
grow_above(pumpkin, ground). @from 2026-11-16T19:48:03 @conf 1 @source teacher:pretrain
```
