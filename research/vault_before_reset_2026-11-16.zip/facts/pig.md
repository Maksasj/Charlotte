# pig

```datalog
is_a(pig, farm_animal). @from 2026-11-16T19:19:42 @conf 1 @source teacher:pretrain
```
