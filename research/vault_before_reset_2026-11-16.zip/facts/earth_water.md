# earth_water

```datalog
located_in(earth_water, ocean). @from 2026-11-16T19:59:49 @conf 1 @source teacher:pretrain
```
