# quick_release_lever

```datalog
hold(quick_release_lever, wheel). @from 2026-11-16T21:09:18 @conf 1 @source teacher:train
```
