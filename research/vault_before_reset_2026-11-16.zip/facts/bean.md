# bean

```datalog
proper_name(bean). @from 2026-11-16T20:29:48 @conf 1 @source parser
```
