# br_tchen

```datalog
proper_name("brötchen"). @from 2026-11-16T20:27:26 @conf 1 @source parser
```
