# edo

```datalog
proper_name(edo). @from 2026-11-16T20:02:13 @conf 1 @source parser
```
