# librarian

```datalog
work_in(librarian, library). @from 2026-11-16T19:24:27 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:24:33
```
