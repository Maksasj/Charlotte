# apple_orchard

```datalog
is_a(apple_orchard, place). @from 2026-11-16T20:25:38 @conf 1 @source teacher:chat
has(apple_orchard, apple_tree). @from 2026-11-16T20:25:38 @conf 1 @source teacher:chat
```
