# old_street

```datalog
property(old_street, quality, narrow). @from 2026-11-16T20:28:56 @conf 1 @source teacher:chat
property(old_street, quality, winding). @from 2026-11-16T20:28:56 @conf 1 @source teacher:chat
```
