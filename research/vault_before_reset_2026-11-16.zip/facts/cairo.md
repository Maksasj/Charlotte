# cairo

```datalog
proper_name(cairo). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(cairo, egypt). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
```
