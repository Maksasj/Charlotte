# canada

```datalog
proper_name(canada). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(canada, north_america). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
-located_in(canada, africa). @from 2026-11-16T19:21:23 @conf 1 @source teacher:pretrain
is_a(canada, country). @from 2026-11-16T19:21:26 @conf 1 @source teacher:pretrain
```
