# green

```datalog
proper_name(green). @from 2026-11-16T20:10:32 @conf 1 @source parser
```
