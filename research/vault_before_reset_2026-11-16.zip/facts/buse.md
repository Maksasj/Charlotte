# buse

```datalog
property(buse, size, big). @from 2026-11-16T19:16:44 @until 2026-11-16T19:16:52 @conf 1 @source teacher:pretrain
```
