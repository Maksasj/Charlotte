# lion_group

```datalog
is_a(lion_group, pride). @from 2026-11-16T19:40:58 @conf 1 @source teacher:pretrain
```
