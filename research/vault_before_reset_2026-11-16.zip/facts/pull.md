# pull

```datalog
proper_name(pull). @from 2026-11-16T20:58:31 @conf 1 @source parser
```
