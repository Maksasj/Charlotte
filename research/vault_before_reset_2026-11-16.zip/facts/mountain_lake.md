# mountain_lake

```datalog
located_in(mountain_lake, bowl). @from 2026-11-16T20:26:40 @conf 1 @source teacher:chat
property(mountain_lake, quality, cold). @from 2026-11-16T20:26:40 @conf 1 @source teacher:chat
property(mountain_lake, quality, clear). @from 2026-11-16T20:26:55 @conf 1 @source teacher:chat
```
