# moon

```datalog
proper_name(moon). @from 2026-11-16T20:27:39 @conf 1 @source parser
is_a(moon, world). @from 2026-11-16T20:27:39 @conf 1 @source teacher:chat
go_around(moon, earth). @from 2026-11-16T20:27:39 @conf 1 @source teacher:chat
property(moon, quality, big). @from 2026-11-16T20:27:55 @conf 1 @source teacher:chat
take(moon, month). @from 2026-11-16T20:27:55 @conf 1 @source teacher:chat
property(moon, quality, shape_different_each_night). @from 2026-11-16T20:27:55 @conf 1 @source teacher:chat
```
