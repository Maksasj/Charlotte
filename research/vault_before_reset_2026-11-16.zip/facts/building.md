# building

```datalog
property(building, size, tall). @from 2026-11-16T20:27 @until 2026-11-16T20:27:58 @conf 1 @source teacher:chat
```
