# planet

```datalog
property(planet, size, big). @from 2026-11-16T19:21:33 @until 2026-11-16T19:22:15 @conf 1 @source teacher:pretrain
is_a(planet, world). @from 2026-11-16T20:24:42 @conf 1 @source teacher:chat
property(planet, size, big). @from 2026-11-16T20:24:42 @conf 1 @source teacher:chat
property(planet, quality, round). @from 2026-11-16T20:24:42 @conf 1 @source teacher:chat
circle(planet, star). @from 2026-11-16T20:24:42 @conf 1 @source teacher:chat
-twinkle(planet). @from 2026-11-16T20:24:42 @conf 1 @source teacher:chat
property(planet, quality, steady). @from 2026-11-16T20:24:42 @conf 1 @source teacher:chat
go_around(planet, star). @from 2026-11-16T20:25:01 @conf 1 @source teacher:chat
```
