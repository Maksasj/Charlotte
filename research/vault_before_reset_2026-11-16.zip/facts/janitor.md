# janitor

```datalog
clean(janitor, school). @from 2026-11-16T19:24:01 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:24:21
is_a(janitor, worker). @from 2026-11-16T19:24:57 @conf 1 @source teacher:pretrain
```
