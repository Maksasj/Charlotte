# napkins

```datalog
proper_name(napkins). @from 2026-11-16T21:05:14 @conf 1 @source parser
```
