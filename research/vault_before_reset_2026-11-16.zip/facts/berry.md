# berry

```datalog
property(berry, quality, juicy). @from 2026-11-16T20:25:37 @conf 1 @source teacher:chat
located_in(berry, batter). @from 2026-11-16T20:25:37 @until 2026-11-16T20:27:56 @conf 1 @source teacher:chat
```
