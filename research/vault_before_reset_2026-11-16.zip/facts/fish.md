# fish

```datalog
has(fish, fin). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
has(fish, gill). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
swim(fish). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
located_in(fish, water). @from 2026-11-16T19:18:34 @until 2026-11-16T19:18:34 @conf 1 @source teacher:pretrain
located_in(fish, breathe_with_gill). @from 2026-11-16T19:18:34 @until 2026-11-16T19:19:32 @conf 1 @source teacher:pretrain
-live_on(fish, land). @from 2026-11-16T19:18:48 @conf 1 @source teacher:pretrain
located_in(fish, water). @from 2026-11-16T19:19:32 @conf 1 @source teacher:pretrain
use(fish, gill). @from 2026-11-16T19:38:17 @conf 1 @source teacher:pretrain
take_in(fish, water). @from 2026-11-16T19:38:17 @conf 1 @source teacher:pretrain
take_in_through(fish, mouth). @from 2026-11-16T19:39:15 @conf 1 @source teacher:pretrain
wants(fish, oxygen). @from 2026-11-16T19:40:38 @conf 1 @source teacher:pretrain
has(fish, swim_bladder). @from 2026-11-16T19:41:58 @conf 1 @source teacher:pretrain
has(fish, scale). @from 2026-11-16T19:43:33 @conf 1 @source teacher:pretrain
swim_in(fish, water). @from 2026-11-16T20:28:26 @conf 1 @source teacher:chat
breathe_through(fish, gill). @from 2026-11-16T20:28:26 @conf 1 @source teacher:chat
-make(fish, body_heat). @from 2026-11-16T20:28:41 @conf 1 @source teacher:chat
take(fish, water_temperature). @from 2026-11-16T20:28:41 @conf 1 @source teacher:chat
-make(fish, heat). @from 2026-11-16T20:28:58 @conf 1 @source teacher:chat
```
