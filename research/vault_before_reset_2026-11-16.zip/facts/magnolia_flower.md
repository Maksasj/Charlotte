# magnolia_flower

```datalog
part_of(magnolia_flower, magnolia_tree). @from 2026-11-16T20:29:42 @conf 1 @source teacher:chat
property(magnolia_flower, size, huge). @from 2026-11-16T20:29:42 @until 2026-11-16T20:29:56 @conf 1 @source teacher:chat
property(magnolia_flower, colour, pink). @from 2026-11-16T20:29:42 @until 2026-11-16T20:29:42 @conf 1 @source teacher:chat
property(magnolia_flower, colour, white). @from 2026-11-16T20:29:42 @until 2026-11-16T20:29:56 @conf 1 @source teacher:chat
property(magnolia_flower, size, big). @from 2026-11-16T20:29:56 @conf 1 @source teacher:chat
property(magnolia_flower, quality, cup_shaped). @from 2026-11-16T20:29:56 @conf 1 @source teacher:chat
property(magnolia_flower, colour, pink). @from 2026-11-16T20:29:56 @until 2026-11-16T20:29:56 @conf 1 @source teacher:chat
property(magnolia_flower, colour, white). @from 2026-11-16T20:29:56 @conf 1 @source teacher:chat
```
