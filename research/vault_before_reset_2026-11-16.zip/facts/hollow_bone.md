# hollow_bone

```datalog
property(hollow_bone, quality, light). @from 2026-11-16T19:40:24 @conf 1 @source teacher:pretrain
```
