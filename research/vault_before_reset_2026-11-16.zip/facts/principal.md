# principal

```datalog
lead(principal, school). @from 2026-11-16T19:23:53 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:24:01
is_a(principal, worker). @from 2026-11-16T19:25:04 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:12:12
work_at(principal, school). @from 2026-11-16T20:12:49 @conf 1 @source teacher:pretrain
is_a(principal, school_leader). @from 2026-11-16T20:12:49 @conf 1 @source teacher:pretrain
```
