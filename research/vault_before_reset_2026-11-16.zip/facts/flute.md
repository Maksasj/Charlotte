# flute

```datalog
is_a(flute, wind_instrument). @from 2026-11-16T19:24:50 @conf 1 @source teacher:pretrain
```
