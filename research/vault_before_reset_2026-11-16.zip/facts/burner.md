# burner

```datalog
part_of(burner, stove). @from 2026-11-16T19:52:59 @conf 1 @source teacher:pretrain
```
