# red_blood_cell

```datalog
has(red_blood_cell, hemoglobin). @from 2026-11-16T20:29:49 @conf 1 @source teacher:chat
```
