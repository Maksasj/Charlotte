# africa

```datalog
proper_name(africa). @from 2026-11-16T19:15:42 @conf 1 @source parser
is_a(africa, continent). @from 2026-11-16T19:20:50 @conf 1 @source teacher:pretrain
is_a(africa, both_continent). @from 2026-11-16T19:21:46 @until 2026-11-16T19:21:51 @conf 1 @source teacher:pretrain
```
