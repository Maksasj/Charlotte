# oatmeal

```datalog
proper_name(oatmeal). @from 2026-11-16T19:21:05 @conf 1 @source parser
is_a(oatmeal, breakfast_food). @from 2026-11-16T19:21:05 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:52:31
property(oatmeal, quality, warm). @from 2026-11-16T19:47:46 @until 2026-11-16T19:47:46 @conf 1 @source teacher:pretrain
property(oatmeal, quality, soft). @from 2026-11-16T19:47:46 @until 2026-11-16T19:48:35 @conf 1 @source teacher:pretrain
property(oatmeal, quality, warm). @from 2026-11-16T19:48:35 @conf 1 @source teacher:pretrain
```
