# magnolia

```datalog
proper_name(magnolia). @from 2026-11-16T20:29:56 @conf 1 @source parser
```
