# chainring

```datalog
is_a(chainring, big_gear). @from 2026-11-16T20:16:57 @conf 1 @source teacher:pretrain
proper_name(chainring). @from 2026-11-16T20:17:33 @conf 1 @source parser
```
