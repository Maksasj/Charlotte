# pan

```datalog
cook(pan, food). @from 2026-11-16T19:20:45 @conf 1 @source teacher:pretrain
is_a(pan, container). @from 2026-11-16T19:52:59 @conf 1 @source teacher:pretrain
property(pan, quality, flat). @from 2026-11-16T19:52:59 @conf 1 @source teacher:pretrain
property(pan, quality, good_for_eggs_and_frying). @from 2026-11-16T20:29:48 @conf 1 @source teacher:chat
property(pan, size, small). @from 2026-11-16T20:32:04 @conf 1 @source teacher:chat
```
