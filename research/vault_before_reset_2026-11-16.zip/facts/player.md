# player

```datalog
cover(player, ground). @from 2026-11-16T20:22:28 @conf 1 @source teacher:chat
-grab(player, ball). @from 2026-11-16T20:24:47 @conf 1 @source teacher:chat
-check(player, pressure). @from 2026-11-16T20:26:48 @conf 1 @source teacher:chat
property(player, quality, ready). @from 2026-11-16T20:27:06 @conf 1 @source teacher:chat
```
