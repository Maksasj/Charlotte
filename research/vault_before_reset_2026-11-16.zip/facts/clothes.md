# clothes

```datalog
hang_in(clothes, closet). @from 2026-11-16T20:11:28 @conf 1 @source teacher:pretrain
```
