# oat

```datalog
cook_in(oat, water). @from 2026-11-16T19:50:11 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:50:11
cook_in(oat, milk). @from 2026-11-16T19:50:11 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:50:11
is_a(oat, grain). @from 2026-11-16T19:51:01 @conf 1 @source teacher:pretrain
```
