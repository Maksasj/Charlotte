# lightning

```datalog
proper_name(lightning). @from 2026-11-16T19:17:56 @conf 1 @source parser
property(lightning, quality, electricity). @from 2026-11-16T19:17:56 @conf 1 @source teacher:pretrain
```
