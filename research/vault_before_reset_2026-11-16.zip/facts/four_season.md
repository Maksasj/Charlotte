# four_season

```datalog
come_in(four_season, year). @from 2026-11-16T19:21:28 @conf 1 @source teacher:pretrain
```
