# living

```datalog
proper_name(living). @from 2026-11-16T19:17:33 @conf 1 @source parser
```
