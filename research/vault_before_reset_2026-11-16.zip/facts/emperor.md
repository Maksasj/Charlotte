# emperor

```datalog
proper_name(emperor). @from 2026-11-16T19:49:03 @conf 1 @source parser
located_in(emperor, tokyo). @from 2026-11-16T19:49:10 @conf 1 @source teacher:pretrain
```
