# cold

```datalog
proper_name(cold). @from 2026-11-16T19:47:19 @conf 1 @source parser
```
