# baker

```datalog
has(baker, oven). @from 2026-11-16T19:16:21 @conf 1 @source teacher:pretrain
work_in(baker, shop). @from 2026-11-16T19:24:13 @conf 1 @source teacher:pretrain
make(baker, bread). @from 2026-11-16T19:24:13 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:26:09
```
