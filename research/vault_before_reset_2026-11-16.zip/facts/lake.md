# lake

```datalog
is_a(lake, pool). @from 2026-11-16T20:28:50 @conf 1 @source teacher:chat
property(lake, size, big). @from 2026-11-16T20:28:50 @conf 1 @source teacher:chat
```
