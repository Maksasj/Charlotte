# family

```datalog
has(family, hagelslag). @from 2026-11-16T20:26:25 @conf 1 @source teacher:chat
```
