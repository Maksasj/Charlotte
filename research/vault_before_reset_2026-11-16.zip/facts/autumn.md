# autumn

```datalog
proper_name(autumn). @from 2026-11-16T19:22:04 @conf 1 @source parser
is_a(autumn, season). @from 2026-11-16T19:22:04 @conf 1 @source teacher:pretrain
come_after(autumn, summer). @from 2026-11-16T19:22:04 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T20:03:22
come_before(autumn, winter). @from 2026-11-16T19:22:11 @conf 1 @source teacher:pretrain
follow_by(autumn, winter). @from 2026-11-16T19:59:15 @conf 1 @source teacher:pretrain
```
