# lemonade

```datalog
proper_name(lemonade). @from 2026-11-16T20:30:18 @conf 1 @source parser
located_in(lemonade, fridge). @from 2026-11-16T20:30:18 @conf 1 @source teacher:chat
property(lemonade, quality, nice). @from 2026-11-16T20:30:18 @conf 1 @source teacher:chat
property(lemonade, quality, sweet). @from 2026-11-16T20:30:18 @conf 1 @source teacher:chat
property(lemonade, quality, sour). @from 2026-11-16T20:30:18 @conf 1 @source teacher:chat
```
