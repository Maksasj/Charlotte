# picnic

```datalog
location(picnic, park). @from 2026-11-16T21:04:53 @until 2026-11-16T21:06:25 @conf 1 @source teacher:train
time(picnic, weekend). @from 2026-11-16T21:04:53 @conf 1 @source teacher:train
```
