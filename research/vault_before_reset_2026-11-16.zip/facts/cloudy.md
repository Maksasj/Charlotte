# cloudy

```datalog
proper_name(cloudy). @from 2026-11-16T20:23:44 @conf 1 @source parser
```
