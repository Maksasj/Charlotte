# coat

```datalog
is_a(coat, clothe). @from 2026-11-16T19:23:59 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:23:59
```
