# quick

```datalog
proper_name(quick). @from 2026-11-16T19:37:46 @conf 1 @source parser
```
