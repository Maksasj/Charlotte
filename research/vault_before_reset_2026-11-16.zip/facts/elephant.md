# elephant

```datalog
has(elephant, trunk). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
property(elephant, size, big). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
is_a(elephant, bigger_than_horse). @from 2026-11-16T19:22:40 @conf 1 @source teacher:pretrain
```
