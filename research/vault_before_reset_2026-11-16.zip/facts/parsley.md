# parsley

```datalog
is_a(parsley, herb). @from 2026-11-16T20:57:07 @conf 1 @source teacher:train
property(parsley, quality, easy). @from 2026-11-16T20:57:07 @conf 1 @source teacher:train
wants(parsley, water). @from 2026-11-16T20:57:07 @conf 1 @source teacher:train
handle(parsley, light). @from 2026-11-16T21:07:14 @conf 1 @source teacher:train
```
