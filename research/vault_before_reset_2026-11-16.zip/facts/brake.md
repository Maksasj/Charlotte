# brake

```datalog
part_of(brake, car). @from 2026-11-16T19:23:34 @conf 1 @source teacher:pretrain
proper_name(brake). @from 2026-11-16T19:23:47 @conf 1 @source parser
is_a(brake, part_that_stops_car). @from 2026-11-16T19:23:47 @conf 1 @source teacher:pretrain
```
