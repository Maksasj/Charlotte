# purple_grape

```datalog
is_a(purple_grape, grape). @from 2026-11-16T20:10:38 @conf 1 @source teacher:pretrain
```
