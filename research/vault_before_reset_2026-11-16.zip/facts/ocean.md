# ocean

```datalog
is_a(ocean, big_sea). @from 2026-11-16T19:21:23 @conf 1 @source teacher:pretrain
is_a(ocean, big_salty_sea). @from 2026-11-16T19:21:26 @conf 1 @source teacher:pretrain
property(ocean, size, big). @from 2026-11-16T19:21:46 @conf 1 @source teacher:pretrain
has(ocean, salt_water). @from 2026-11-16T19:21:46 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:22:09
cover(ocean, earth_surface). @from 2026-11-16T19:55:38 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:56:41
part_of(ocean, earth_water). @from 2026-11-16T19:56:41 @conf 1 @source teacher:pretrain
property(ocean, quality, deep). @from 2026-11-16T20:28:04 @conf 1 @source teacher:chat
proper_name(ocean). @from 2026-11-16T20:31:35 @conf 1 @source parser
```
