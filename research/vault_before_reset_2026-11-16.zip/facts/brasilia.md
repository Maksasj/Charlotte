# brasilia

```datalog
proper_name(brasilia). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(brasilia, brazil). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
```
