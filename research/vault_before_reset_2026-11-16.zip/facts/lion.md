# lion

```datalog
is_a(lion, wild_animal). @from 2026-11-16T19:18:49 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:18:55
is_a(lion, mammal). @from 2026-11-16T19:19:17 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:23
live_on(lion, land). @from 2026-11-16T19:19:40 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:40
is_a(lion, wild_cat). @from 2026-11-16T19:37:17 @conf 1 @source teacher:pretrain
located_in(lion, africa). @from 2026-11-16T19:37:17 @until 2026-11-16T19:37:51 @conf 1 @source teacher:pretrain
live_in(lion, pride). @from 2026-11-16T19:37:17 @conf 1 @source teacher:pretrain
located_in(lion, pride). @from 2026-11-16T19:37:51 @until 2026-11-16T19:38:46 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:37:51
located_in(lion, africa). @from 2026-11-16T19:38:46 @until 2026-11-16T19:39:37 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:38:46
-located_in(lion, pride). @from 2026-11-16T19:38:46 @until 2026-11-16T19:39:37 @conf 1 @source teacher:pretrain
located_in(lion, pride). @from 2026-11-16T19:39:37 @until 2026-11-16T19:43:06 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:42:15
part_of(lion, pride). @from 2026-11-16T19:43:06 @conf 1 @source teacher:pretrain
located_in(lion, africa). @from 2026-11-16T19:43:06 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T19:44:38
live_in(lion, group). @from 2026-11-16T19:45:30 @conf 1 @source teacher:pretrain
is_a(lion, cat). @from 2026-11-16T20:26:59 @conf 1 @source teacher:chat
has(lion, mane). @from 2026-11-16T20:26:59 @conf 1 @source teacher:chat
is_a(lion, animal). @from 2026-11-16T20:27:40 @conf 1 @source teacher:chat
property(lion, size, big). @from 2026-11-16T20:27:40 @conf 1 @source teacher:chat
property(lion, quality, impressive). @from 2026-11-16T20:27:56 @conf 1 @source teacher:chat
```
