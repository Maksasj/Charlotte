# next

```datalog
proper_name(next). @from 2026-11-16T20:00:22 @conf 1 @source parser
```
