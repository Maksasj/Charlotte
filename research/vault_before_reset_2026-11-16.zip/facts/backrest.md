# backrest

```datalog
part_of(backrest, chair). @from 2026-11-16T20:09:19 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T20:10:32
```
