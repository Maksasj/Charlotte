# india

```datalog
proper_name(india). @from 2026-11-16T19:20:29 @conf 1 @source parser
is_a(india, country_in_asia). @from 2026-11-16T19:20:29 @conf 1 @source teacher:pretrain
is_a(india, country). @from 2026-11-16T19:20:42 @conf 1 @source teacher:pretrain
located_in(india, asia). @from 2026-11-16T19:47:38 @conf 1 @source teacher:pretrain
property(india, size, big). @from 2026-11-16T19:48:27 @conf 1 @source teacher:pretrain
```
