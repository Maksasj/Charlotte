# banana

```datalog
property(banana, quality, fruit). @from 2026-11-16T19:19:17 @conf 1 @source teacher:pretrain
property(banana, colour, yellow). @from 2026-11-16T19:22:38 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T20:07:05
is_a(banana, fruit). @from 2026-11-16T19:25:53 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T20:04:26
is_a(banana, berry). @from 2026-11-16T20:03:56 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:04:26
```
