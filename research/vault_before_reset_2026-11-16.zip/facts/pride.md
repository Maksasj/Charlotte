# pride

```datalog
is_a(pride, group). @from 2026-11-16T19:39:37 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:39:37
has(pride, female). @from 2026-11-16T19:41:40 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:41:40
has(pride, cub). @from 2026-11-16T19:41:40 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:41:40
has(pride, male). @from 2026-11-16T19:41:40 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:41:40
```
