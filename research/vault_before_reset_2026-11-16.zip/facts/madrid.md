# madrid

```datalog
proper_name(madrid). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(madrid, spain). @from 2026-11-16T19:15:42 @until 2026-11-16T19:51:05 @conf 1 @source teacher:pretrain
is_a(madrid, city). @from 2026-11-16T19:51:05 @conf 1 @source teacher:pretrain
is_a(madrid, capital). @from 2026-11-16T19:51:05 @conf 1 @source teacher:pretrain
property(madrid, capital_of, spain). @from 2026-11-16T19:51:05 @conf 1 @source teacher:pretrain
located_in(madrid, middle_of_spain). @from 2026-11-16T19:51:05 @until 2026-11-16T19:52:38 @conf 1 @source teacher:pretrain
located_in(madrid, spain). @from 2026-11-16T19:52:38 @conf 1 @source teacher:pretrain
is_a(madrid, european_city). @from 2026-11-16T20:31:37 @conf 1 @source teacher:chat
```
