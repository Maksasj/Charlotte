# basil

```datalog
proper_name(basil). @from 2026-11-16T20:26:51 @conf 1 @source parser
is_a(basil, herb). @from 2026-11-16T20:26:51 @conf 1 @source teacher:chat
property(basil, quality, leafy). @from 2026-11-16T20:26:51 @conf 1 @source teacher:chat
likes(basil, warm_weather). @from 2026-11-16T20:26:51 @conf 1 @source teacher:chat
property(basil, quality, sweet). @from 2026-11-16T20:26:51 @conf 1 @source teacher:chat
property(basil, quality, peppery). @from 2026-11-16T20:26:51 @conf 1 @source teacher:chat
located_in(basil, garden). @from 2026-11-16T20:27:22 @until 2026-11-16T20:27:22 @conf 1 @source teacher:chat
located_in(basil, fridge). @from 2026-11-16T20:27:22 @until 2026-11-16T20:27:47 @conf 1 @source teacher:chat
property(basil, quality, wilted). @from 2026-11-16T20:27:22 @until 2026-11-16T20:27:47 @conf 1 @source teacher:chat
```
