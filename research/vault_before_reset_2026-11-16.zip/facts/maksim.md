# maksim

```datalog
proper_name(maksim). @from 2026-11-16T19:12:31 @conf 1 @source parser
likes(maksim, grape). @from 2026-11-16T19:12:46 @conf 1 @source user @uses 3 @last 2026-11-16T20:29:59
learn(maksim, that). @from 2026-11-16T19:21:38 @conf 1 @source teacher:pretrain
-should(maksim, greet). @from 2026-11-16T19:23:42 @until 2026-11-16T19:25:11 @conf 1 @source teacher:pretrain
-see(maksim, dog). @from 2026-11-16T19:37:38 @until 2026-11-16T19:46:04 @conf 1 @source teacher:pretrain
likes(maksim, berlin). @from 2026-11-16T19:51:04 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:29:59
likes(maksim, meeting_you). @from 2026-11-16T19:55:48 @until 2026-11-16T20:03:07 @conf 1 @source teacher:pretrain
-is_a(maksim, whale). @from 2026-11-16T19:58:29 @conf 1 @source teacher:pretrain
wrap(maksim, scarf). @from 2026-11-16T20:10:15 @until 2026-11-16T20:12:50 @conf 1 @source teacher:pretrain
squeeze(maksim, handle_of_pliers). @from 2026-11-16T20:10:19 @conf 1 @source teacher:pretrain
hold(maksim, pliers). @from 2026-11-16T20:10:19 @conf 1 @source teacher:pretrain
make(maksim, tea). @from 2026-11-16T20:21:13 @conf 1 @source teacher:chat
sit_by(maksim, window). @from 2026-11-16T20:21:13 @conf 1 @source teacher:chat
has(maksim, pear_tree). @until 2026-11-16T20:23:44 @conf 1 @source teacher:chat
likes(maksim, chess). @from 2026-11-16T20:25:46 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:29:59
likes(maksim, bread). @from 2026-11-16T20:25:52 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:29:59
likes(maksim, rough_plan). @from 2026-11-16T20:29:57 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:29:59
likes(maksim, surprise). @from 2026-11-16T20:29:57 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:29:59
property(maksim, quality, like_that). @from 2026-11-16T20:30:14 @conf 1 @source teacher:chat
head_to(maksim, beach). @from 2026-11-16T20:56:47 @conf 1 @source teacher:train
```
