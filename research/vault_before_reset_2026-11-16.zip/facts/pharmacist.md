# pharmacist

```datalog
is_a(pharmacist, health_worker). @from 2026-11-16T19:24:47 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:24:47
```
