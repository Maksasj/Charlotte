# day_trip

```datalog
bring(day_trip, sunscreen). @from 2026-11-16T20:57:13 @conf 1 @source teacher:train
bring(day_trip, drinking_water). @from 2026-11-16T20:57:13 @conf 1 @source teacher:train
bring(day_trip, hat). @from 2026-11-16T20:57:13 @conf 1 @source teacher:train
bring(day_trip, sunglasses). @from 2026-11-16T20:57:13 @conf 1 @source teacher:train
bring(day_trip, towel). @from 2026-11-16T20:57:13 @conf 1 @source teacher:train
bring(day_trip, swimsuit). @from 2026-11-16T20:57:13 @conf 1 @source teacher:train
bring(day_trip, clothes_change). @from 2026-11-16T20:57:13 @conf 1 @source teacher:train
bring(day_trip, snack). @from 2026-11-16T20:57:13 @conf 1 @source teacher:train
```
