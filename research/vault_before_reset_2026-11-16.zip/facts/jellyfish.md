# jellyfish

```datalog
is_a(jellyfish, ocean_animal). @from 2026-11-16T20:31:35 @conf 1 @source teacher:chat
```
