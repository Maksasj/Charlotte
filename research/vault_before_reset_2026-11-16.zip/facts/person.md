# person

```datalog
eat(person, bagel). @from 2026-11-16T19:54:19 @conf 1 @source teacher:pretrain
eat_at(person, breakfast). @from 2026-11-16T19:54:19 @conf 1 @source teacher:pretrain
spread_on(person, cream_cheese). @from 2026-11-16T19:55:09 @until 2026-11-16T19:55:19 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:55:09
ride_with(person, no_hand). @from 2026-11-16T20:25:49 @until 2026-11-16T20:28:06 @conf 1 @source teacher:chat
float_in(person, dead_sea). @from 2026-11-16T20:30:48 @conf 1 @source teacher:chat
float(person). @from 2026-11-16T20:31:32 @conf 1 @source teacher:chat
wants(person, sandwich). @from 2026-11-16T21:06:21 @conf 1 @source teacher:train
wants(person, apple). @from 2026-11-16T21:06:21 @until 2026-11-16T21:06:25 @conf 1 @source teacher:train
wants(person, cheese). @from 2026-11-16T21:06:21 @until 2026-11-16T21:06:25 @conf 1 @source teacher:train
wants(person, cracker). @from 2026-11-16T21:06:21 @until 2026-11-16T21:06:25 @conf 1 @source teacher:train
wants(person, grape). @from 2026-11-16T21:06:21 @until 2026-11-16T21:06:25 @conf 1 @source teacher:train
```
