# leave

```datalog
property(leave, colour, green). @from 2026-11-16T19:17:02 @until 2026-11-16T19:17:13 @conf 1 @source teacher:pretrain
```
