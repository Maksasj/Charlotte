# bicycle

```datalog
is_a(bicycle, vehicle). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:24:16
has(bicycle, two_wheel). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:12:32
has(bicycle, pedal). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:12:32
property(bicycle, size, small). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain
has(bicycle, wheel). @from 2026-11-16T20:12:32 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:12:32
```
