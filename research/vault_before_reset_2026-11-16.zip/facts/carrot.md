# carrot

```datalog
is_a(carrot, vegetable). @from 2026-11-16T19:15:24 @conf 1 @source teacher:pretrain @uses 4 @last 2026-11-16T19:26:09
property(carrot, colour, orange). @from 2026-11-16T19:22:22 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T20:06:23
grow_under(carrot, ground). @from 2026-11-16T19:46:13 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:50:28
```
