# broccoli

```datalog
proper_name(broccoli). @from 2026-11-16T19:20:46 @conf 1 @source parser
is_a(broccoli, vegetable). @from 2026-11-16T19:20:46 @conf 1 @source teacher:pretrain @uses 4 @last 2026-11-16T19:26:09
```
