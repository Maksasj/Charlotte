# does

```datalog
proper_name(does). @from 2026-11-16T19:25:05 @conf 1 @source parser
```
