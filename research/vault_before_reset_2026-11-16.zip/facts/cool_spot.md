# cool_spot

```datalog
property(cool_spot, quality, part_of_house_cooler). @from 2026-11-16T20:28:44 @conf 1 @source teacher:chat
property(cool_spot, quality, cooler_than_rest). @from 2026-11-16T20:28:44 @conf 1 @source teacher:chat
part_of(cool_spot, house). @from 2026-11-16T20:28:44 @conf 1 @source teacher:chat
is_a(cool_spot, place). @from 2026-11-16T20:28:59 @conf 1 @source teacher:chat
```
