# pear

```datalog
is_a(pear, fruit). @from 2026-11-16T20:26:27 @conf 1 @source teacher:chat
grow_on(pear, pear_tree). @from 2026-11-16T20:26:27 @conf 1 @source teacher:chat
property(pear, quality, good). @from 2026-11-16T20:28:55 @conf 1 @source teacher:chat
grow_on(pear, tree). @from 2026-11-16T20:28:55 @conf 1 @source teacher:chat
hang_from(pear, branch). @from 2026-11-16T20:29:58 @conf 1 @source teacher:chat
has(pear, branch). @from 2026-11-16T20:30:14 @conf 1 @source teacher:chat
hang(pear). @from 2026-11-16T20:30:14 @conf 1 @source teacher:chat
property(pear, quality, sweeter_when_ripe). @from 2026-11-16T20:30:44 @conf 1 @source teacher:chat
```
