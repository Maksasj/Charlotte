# football

```datalog
is_a(football, game). @from 2026-11-16T20:24:47 @conf 1 @source teacher:chat
made_of(football, leather). @from 2026-11-16T20:25:43 @until 2026-11-16T20:28:17 @conf 1 @source teacher:chat
made_of(football, polyurethane). @from 2026-11-16T20:25:43 @conf 1 @source teacher:chat
property(football, outer_shell, polyurethane). @from 2026-11-16T20:25:43 @conf 1 @source teacher:chat
property(football, inside, air). @from 2026-11-16T20:25:59 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:25:59
```
