# heart

```datalog
part_of(heart, human_body). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
is_a(heart, muscle). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:26:25
located_in(heart, chest). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
pump(heart, blood). @from 2026-11-16T19:25:54 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:25:55
property(heart, quality, beats_100000_times_a_day). @from 2026-11-16T20:28:49 @conf 1 @source teacher:chat
property(heart, quality, speeds_up_when_running). @from 2026-11-16T20:28:49 @conf 1 @source teacher:chat
pump(heart). @from 2026-11-16T20:30:13 @conf 1 @source teacher:chat
```
