# rain

```datalog
proper_name(rain). @from 2026-11-16T19:17:56 @conf 1 @source parser
part_of(rain, water_cycle). @from 2026-11-16T19:17:56 @conf 1 @source teacher:pretrain
fall_from(rain, cloud). @from 2026-11-16T19:21:27 @conf 1 @source teacher:pretrain
is_a(rain, water). @from 2026-11-16T20:03:02 @conf 1 @source teacher:pretrain
come_down_from(rain, cloud). @from 2026-11-16T20:03:16 @conf 1 @source teacher:pretrain
fall_on(rain, mountain). @from 2026-11-16T20:29:44 @conf 1 @source teacher:chat
stay_in(rain, lake). @from 2026-11-16T20:29:44 @conf 1 @source teacher:chat
move_to(rain, river). @from 2026-11-16T20:29:44 @conf 1 @source teacher:chat
soak_through(rain, thin_cloth). @from 2026-11-16T20:55:24 @conf 1 @source teacher:train
causes(rain, wet). @from 2026-11-16T21:02:45 @conf 1 @source teacher:train
```
