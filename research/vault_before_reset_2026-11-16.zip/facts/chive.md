# chive

```datalog
is_a(chive, herb). @from 2026-11-16T20:57:07 @conf 1 @source teacher:train @uses 1 @last 2026-11-16T21:07:24
property(chive, quality, easy). @from 2026-11-16T20:57:07 @conf 1 @source teacher:train @uses 1 @last 2026-11-16T21:07:24
wants(chive, water). @from 2026-11-16T20:57:07 @conf 1 @source teacher:train @uses 1 @last 2026-11-16T21:07:24
handle(chive, light). @from 2026-11-16T21:07:14 @conf 1 @source teacher:train @uses 1 @last 2026-11-16T21:07:24
```
