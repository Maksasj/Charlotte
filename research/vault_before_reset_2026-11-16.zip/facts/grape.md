# grape

```datalog
property(grape, quality, tasty). @from 2026-11-16T19:12:56 @conf 1 @source user
property(grape, colour, green). @from 2026-11-16T20:10:06 @until 2026-11-16T20:10:06 @conf 1 @source teacher:pretrain
property(grape, colour, purple). @from 2026-11-16T20:10:06 @conf 1 @source teacher:pretrain
-change(grape, colour). @from 2026-11-16T20:10:38 @conf 1 @source teacher:pretrain
```
