# green_tea

```datalog
is_a(green_tea, drink). @from 2026-11-16T20:29:06 @conf 1 @source teacher:chat
property(green_tea, quality, light). @from 2026-11-16T20:29:06 @conf 1 @source teacher:chat
property(green_tea, quality, fresh). @from 2026-11-16T20:29:06 @conf 1 @source teacher:chat
made_from(green_tea, tea_leaf). @from 2026-11-16T20:29:06 @conf 1 @source teacher:chat
property(green_tea, quality, grassy). @from 2026-11-16T20:29:06 @conf 1 @source teacher:chat
property(green_tea, quality, gentle). @from 2026-11-16T20:29:06 @conf 1 @source teacher:chat
```
