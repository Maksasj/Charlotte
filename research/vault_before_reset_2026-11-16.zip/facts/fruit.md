# fruit

```datalog
proper_name(fruit). @from 2026-11-16T19:18:34 @conf 1 @source parser
is_a(fruit, plant_part). @from 2026-11-16T19:18:34 @conf 1 @source teacher:pretrain @uses 4 @last 2026-11-16T20:04:26
grow_on(fruit, plant). @from 2026-11-16T19:18:37 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:07
has(fruit, seed). @from 2026-11-16T19:18:49 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:07
grow_from(fruit, flower). @from 2026-11-16T19:18:52 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:07
is_a(fruit, plant). @from 2026-11-16T19:25:25 @until 2026-11-16T19:26:47 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T19:26:09
part_of(fruit, plant). @from 2026-11-16T20:26:12 @conf 1 @source teacher:chat
```
