# just

```datalog
proper_name(just). @from 2026-11-16T19:41:30 @conf 1 @source parser
```
