# japanese_people

```datalog
eat(japanese_people, rice). @from 2026-11-16T20:22:44 @conf 1 @source teacher:chat
eat(japanese_people, fish). @from 2026-11-16T20:22:44 @conf 1 @source teacher:chat
eat(japanese_people, miso_soup). @from 2026-11-16T20:22:44 @conf 1 @source teacher:chat
```
