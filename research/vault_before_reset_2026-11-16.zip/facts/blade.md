# blade

```datalog
part_of(blade, knife). @from 2026-11-16T19:15:59 @conf 1 @source teacher:pretrain
```
