# doctor

```datalog
is_a(doctor, worker). @from 2026-11-16T19:16:21 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:24:11
has(doctor, stethoscope). @from 2026-11-16T19:16:21 @conf 1 @source teacher:pretrain
is_a(doctor, person). @from 2026-11-16T20:12:06 @conf 1 @source teacher:pretrain
diagnose(doctor, sick_person). @from 2026-11-16T20:12:06 @conf 1 @source teacher:pretrain
decide_on(doctor, treatment). @from 2026-11-16T20:12:06 @conf 1 @source teacher:pretrain
examine(doctor, patient). @from 2026-11-16T20:13:17 @conf 1 @source teacher:pretrain
choose(doctor, treatment). @from 2026-11-16T20:17:56 @conf 1 @source teacher:pretrain
property(doctor, quality, useful). @from 2026-11-16T20:28:43 @conf 1 @source teacher:chat
```
