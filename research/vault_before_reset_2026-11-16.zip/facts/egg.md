# egg

```datalog
is_a(egg, breakfast_food). @from 2026-11-16T19:20:11 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:47:09
fry_in(egg, pan). @from 2026-11-16T19:53:46 @conf 1 @source teacher:pretrain
```
