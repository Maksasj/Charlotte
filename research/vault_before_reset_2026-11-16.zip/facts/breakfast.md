# breakfast

```datalog
proper_name(breakfast). @from 2026-11-16T19:19:56 @conf 1 @source parser
is_a(breakfast, morning_meal). @from 2026-11-16T19:20:08 @conf 1 @source teacher:pretrain
is_a(breakfast, meal). @from 2026-11-16T19:46:32 @conf 1 @source teacher:pretrain
```
