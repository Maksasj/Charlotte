# hollow

```datalog
proper_name(hollow). @from 2026-11-16T19:40:15 @conf 1 @source parser
```
