# juice

```datalog
proper_name(juice). @from 2026-11-16T19:20:36 @conf 1 @source parser
is_a(juice, drink). @from 2026-11-16T19:20:36 @conf 1 @source teacher:pretrain
```
