# dolphin

```datalog
is_a(dolphin, ocean_animal). @from 2026-11-16T20:31:35 @conf 1 @source teacher:chat
talk_with(dolphin, click). @from 2026-11-16T20:31:35 @conf 1 @source teacher:chat
```
