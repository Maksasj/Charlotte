# rook

```datalog
move(rook, straight). @from 2026-11-16T20:26:13 @conf 1 @source teacher:chat
property(rook, value, higher_than_bishop). @from 2026-11-16T20:27:30 @conf 1 @source teacher:chat
slide_along(rook, straight_line). @from 2026-11-16T20:27:30 @conf 1 @source teacher:chat
```
