# offside

```datalog
proper_name(offside). @from 2026-11-16T20:27:45 @conf 1 @source parser
```
