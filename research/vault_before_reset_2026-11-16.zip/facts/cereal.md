# cereal

```datalog
proper_name(cereal). @from 2026-11-16T19:20:17 @conf 1 @source parser
is_a(cereal, breakfast_food). @from 2026-11-16T19:20:17 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:47:09
```
