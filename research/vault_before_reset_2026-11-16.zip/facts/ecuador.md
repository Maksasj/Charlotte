# ecuador

```datalog
proper_name(ecuador). @from 2026-11-16T19:58:03 @conf 1 @source parser
```
