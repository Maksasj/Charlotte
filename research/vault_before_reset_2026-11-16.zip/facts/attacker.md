# attacker

```datalog
property(attacker, quality, offside). @from 2026-11-16T20:27:45 @until 2026-11-16T20:28:17 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:28
```
