# bed

```datalog
located_in(bed, bedroom). @from 2026-11-16T19:15:59 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:10:23
property(bed, quality, furniture). @from 2026-11-16T19:17:33 @until 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
has(bed, mattress). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
property(bed, quality, soft). @from 2026-11-16T19:17:33 @until 2026-11-16T19:22:48 @conf 1 @source teacher:pretrain
property(bed, quality, furniture). @from 2026-11-16T19:22:48 @conf 1 @source teacher:pretrain
```
