# ice

```datalog
proper_name(ice). @from 2026-11-16T19:15:02 @conf 1 @source parser
property(ice, quality, cold). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
melt(ice). @from 2026-11-16T20:30:01 @conf 1 @source teacher:chat
take_in(ice, heat). @from 2026-11-16T20:30:01 @conf 1 @source teacher:chat
turn_into(ice, water). @from 2026-11-16T20:30:01 @conf 1 @source teacher:chat
property(ice, quality, wet). @from 2026-11-16T20:30:03 @conf 1 @source teacher:chat
property(ice, quality, slippery). @from 2026-11-16T20:30:03 @conf 1 @source teacher:chat
shrink(ice). @from 2026-11-16T20:30:03 @conf 1 @source teacher:chat
property(ice, quality, wet_soap_like). @from 2026-11-16T20:30:16 @conf 1 @source teacher:chat
```
