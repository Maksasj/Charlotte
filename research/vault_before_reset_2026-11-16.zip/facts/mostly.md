# mostly

```datalog
proper_name(mostly). @from 2026-11-16T20:27:25 @conf 1 @source parser
```
