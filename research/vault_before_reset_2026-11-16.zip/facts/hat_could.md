# hat_could

```datalog
proper_name(hat_could). @from 2026-11-16T21:11:24 @conf 1 @source parser
```
