# cold_muscle

```datalog
property(cold_muscle, quality, slow). @from 2026-11-16T20:29:43 @conf 1 @source teacher:chat
property(cold_muscle, quality, weak). @from 2026-11-16T20:29:43 @conf 1 @source teacher:chat
```
