# i_am

```datalog
is_a(i_am, person). @from 2026-11-16T20:24:34 @conf 1 @source teacher:chat
```
