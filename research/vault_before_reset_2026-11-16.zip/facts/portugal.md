# portugal

```datalog
proper_name(portugal). @from 2026-11-16T19:53:22 @conf 1 @source parser
property(portugal, capital, lisbon). @from 2026-11-16T19:53:29 @conf 1 @source teacher:pretrain
```
