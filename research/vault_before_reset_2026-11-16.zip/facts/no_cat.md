# no_cat

```datalog
likes(no_cat, fish). @from 2026-11-16T19:22:56 @until 2026-11-16T19:23:39 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:23:31
```
