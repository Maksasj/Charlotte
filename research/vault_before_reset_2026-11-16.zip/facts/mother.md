# mother

```datalog
is_a(mother, female_parent). @from 2026-11-16T19:26:35 @conf 1 @source teacher:pretrain
proper_name(mother). @from 2026-11-16T19:26:47 @conf 1 @source parser
is_a(mother, parent). @from 2026-11-16T19:26:47 @conf 1 @source teacher:pretrain
-is_a(mother, child). @from 2026-11-16T19:27:06 @conf 1 @source teacher:pretrain
```
