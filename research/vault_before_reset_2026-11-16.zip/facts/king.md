# king

```datalog
property(king, quality, most_valuable). @from 2026-11-16T20:27:03 @conf 1 @source teacher:chat
property(king, quality, most_valuable_piece). @from 2026-11-16T20:27:15 @conf 1 @source teacher:chat
```
