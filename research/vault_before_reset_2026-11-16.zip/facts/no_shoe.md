# no_shoe

```datalog
cover(no_shoe, your_feet). @from 2026-11-16T19:23:30 @until 2026-11-16T19:24:15 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:23:59
```
