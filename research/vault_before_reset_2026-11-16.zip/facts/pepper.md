# pepper

```datalog
is_a(pepper, cousin). @from 2026-11-16T20:25:09 @conf 1 @source teacher:chat
is_a(pepper, nightshade). @from 2026-11-16T20:25:26 @conf 1 @source teacher:chat
```
