# jupiter_red_spot

```datalog
is_a(jupiter_red_spot, storm). @from 2026-11-16T20:26:54 @conf 1 @source teacher:chat
property(jupiter_red_spot, size, big). @from 2026-11-16T20:26:54 @conf 1 @source teacher:chat
```
