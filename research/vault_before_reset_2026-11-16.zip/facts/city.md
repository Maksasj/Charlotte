# city

```datalog
property(city, size, big). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:47:57
part_of(city, country). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
property(city, quality, busy). @from 2026-11-16T20:24:28 @conf 1 @source teacher:chat
has(city, building). @from 2026-11-16T20:25:14 @conf 1 @source teacher:chat
has(city, car). @from 2026-11-16T20:25:14 @conf 1 @source teacher:chat
has(city, person). @from 2026-11-16T20:25:14 @conf 1 @source teacher:chat
property(city, quality, charming). @from 2026-11-16T20:25:23 @until 2026-11-16T20:27:58 @conf 1 @source teacher:chat
has(city, cafe). @from 2026-11-16T20:25:23 @conf 1 @source teacher:chat
has(city, road). @from 2026-11-16T20:27 @conf 1 @source teacher:chat
```
