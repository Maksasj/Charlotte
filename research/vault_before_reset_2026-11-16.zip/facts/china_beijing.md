# china_beijing

```datalog
proper_name(china_beijing). @from 2026-11-16T19:54:50 @conf 1 @source parser
```
