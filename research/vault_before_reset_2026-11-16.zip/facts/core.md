# core

```datalog
part_of(core, apple). @from 2026-11-16T19:45:50 @conf 1 @source teacher:pretrain
```
