# hokkaido

```datalog
proper_name(hokkaido). @from 2026-11-16T19:49:55 @conf 1 @source parser
is_a(hokkaido, island). @from 2026-11-16T19:50:03 @conf 1 @source teacher:pretrain
```
