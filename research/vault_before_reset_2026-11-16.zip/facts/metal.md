# metal

```datalog
proper_name(metal). @from 2026-11-16T19:25:22 @conf 1 @source parser
is_a(metal, material). @from 2026-11-16T19:25:22 @conf 1 @source teacher:pretrain
is_a(metal, different_material). @from 2026-11-16T19:26:23 @conf 1 @source teacher:pretrain
```
