# frozen

```datalog
proper_name(frozen). @from 2026-11-16T19:22:15 @conf 1 @source parser
mean(frozen, turned_to_ice). @from 2026-11-16T19:22:15 @conf 1 @source teacher:pretrain
```
