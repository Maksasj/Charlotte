# chicken

```datalog
is_a(chicken, farm_animal). @from 2026-11-16T19:19:23 @conf 1 @source teacher:pretrain
```
