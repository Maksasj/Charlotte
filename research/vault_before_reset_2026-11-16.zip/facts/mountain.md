# mountain

```datalog
property(mountain, size, tall). @from 2026-11-16T19:21:46 @conf 1 @source teacher:pretrain
is_a(mountain, tall_hill). @from 2026-11-16T19:21:56 @until 2026-11-16T19:22:03 @conf 1 @source teacher:pretrain
-is_a(mountain, tall_hill). @from 2026-11-16T19:22:03 @conf 1 @source teacher:pretrain
is_a(mountain, much_taller_than_hill). @from 2026-11-16T19:22:03 @conf 1 @source teacher:pretrain
proper_name(mountain). @from 2026-11-16T20:25:02 @conf 1 @source parser
reflect_in(mountain, mountain_lake). @from 2026-11-16T20:26:55 @conf 1 @source teacher:chat
```
