# many_country

```datalog
located_in(many_country, europe). @from 2026-11-16T19:20:17 @conf 1 @source teacher:pretrain
```
