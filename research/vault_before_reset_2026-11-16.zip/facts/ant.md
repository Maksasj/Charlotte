# ant

```datalog
is_a(ant, insect). @from 2026-11-16T19:18:58 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:40
located_in(ant, colony). @from 2026-11-16T19:18:58 @conf 1 @source teacher:pretrain
property(ant, size, small). @from 2026-11-16T19:22:35 @conf 1 @source teacher:pretrain
walk_up(ant, stem). @from 2026-11-16T20:28:29 @conf 1 @source teacher:chat
property(ant, quality, easy_to_spot). @from 2026-11-16T20:28:48 @conf 1 @source teacher:chat
property(ant, colour, black). @from 2026-11-16T20:28:48 @until 2026-11-16T20:28:48 @conf 1 @source teacher:chat
property(ant, colour, brown). @from 2026-11-16T20:28:48 @until 2026-11-16T20:29:02 @conf 1 @source teacher:chat
walk_in(ant, line). @from 2026-11-16T20:28:48 @conf 1 @source teacher:chat
property(ant, colour, black). @from 2026-11-16T20:29:02 @until 2026-11-16T20:29:02 @conf 1 @source teacher:chat
property(ant, colour, brown). @from 2026-11-16T20:29:02 @until 2026-11-16T20:29:02 @conf 1 @source teacher:chat
property(ant, colour, red). @from 2026-11-16T20:29:02 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:30:42
has(ant, antenna). @from 2026-11-16T20:29:42 @conf 1 @source teacher:chat
walk_up(ant, plant_stem). @from 2026-11-16T20:29:42 @conf 1 @source teacher:chat
get(ant, sweet_sap). @from 2026-11-16T20:29:42 @conf 1 @source teacher:chat
```
