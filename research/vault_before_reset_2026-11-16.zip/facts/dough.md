# dough

```datalog
property(dough, quality, stretchy). @from 2026-11-16T20:27:22 @conf 1 @source teacher:chat
```
