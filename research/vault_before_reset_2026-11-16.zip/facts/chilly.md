# chilly

```datalog
property(chilly, quality, spicy). @from 2026-11-16T19:15:25 @until 2026-11-16T19:15:31 @conf 1 @source teacher:pretrain
```
