# paperwork_staff

```datalog
is_a(paperwork_staff, admin_staff). @from 2026-11-16T20:29:23 @conf 1 @source teacher:chat
```
