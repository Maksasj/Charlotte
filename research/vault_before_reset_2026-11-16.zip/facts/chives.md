# chives

```datalog
proper_name(chives). @from 2026-11-16T20:57:07 @conf 1 @source parser
```
