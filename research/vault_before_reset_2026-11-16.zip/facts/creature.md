# creature

```datalog
located_in(creature, tree). @from 2026-11-16T20:24:46 @until 2026-11-16T20:24:46 @conf 1 @source teacher:chat
located_in(creature, bush). @from 2026-11-16T20:24:46 @until 2026-11-16T20:24:46 @conf 1 @source teacher:chat
located_in(creature, leaf). @from 2026-11-16T20:24:46 @until 2026-11-16T20:25:08 @conf 1 @source teacher:chat
located_in(creature, tree). @from 2026-11-16T20:25:08 @until 2026-11-16T20:25:08 @conf 1 @source teacher:chat
located_in(creature, bush). @from 2026-11-16T20:25:08 @until 2026-11-16T20:25:08 @conf 1 @source teacher:chat
located_in(creature, leaf). @from 2026-11-16T20:25:08 @until 2026-11-16T20:28:06 @conf 1 @source teacher:chat
```
