# abdomen

```datalog
part_of(abdomen, insect). @from 2026-11-16T19:40:08 @conf 1 @source teacher:pretrain
is_a(abdomen, body_part). @from 2026-11-16T19:42:58 @conf 1 @source teacher:pretrain
```
