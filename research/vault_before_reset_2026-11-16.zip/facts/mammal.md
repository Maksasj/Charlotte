# mammal

```datalog
has(mammal, hair). @from 2026-11-16T19:19:17 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:23
```
