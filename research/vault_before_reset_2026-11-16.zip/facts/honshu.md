# honshu

```datalog
proper_name(honshu). @from 2026-11-16T19:49:55 @conf 1 @source parser
is_a(honshu, island). @from 2026-11-16T19:50:03 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:58:25
located_in(honshu, japan). @from 2026-11-16T19:57:46 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:58:25
part_of(honshu, japan). @from 2026-11-16T19:58:25 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:58:25
```
