# egypt

```datalog
proper_name(egypt). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(egypt, africa). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
is_a(egypt, country_in_africa). @from 2026-11-16T19:21:33 @conf 1 @source teacher:pretrain
```
