# brother

```datalog
is_a(brother, male_sibling). @from 2026-11-16T19:27:33 @conf 1 @source teacher:pretrain
```
