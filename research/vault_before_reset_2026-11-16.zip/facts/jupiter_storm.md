# jupiter_storm

```datalog
property(jupiter_storm, quality, bigger_than_earth). @from 2026-11-16T20:27:04 @conf 1 @source teacher:chat
```
