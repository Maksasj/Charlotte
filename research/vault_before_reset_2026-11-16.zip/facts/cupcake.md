# cupcake

```datalog
is_a(cupcake, cake). @from 2026-11-16T20:26:35 @conf 1 @source teacher:chat
```
