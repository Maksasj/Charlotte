# lions

```datalog
proper_name(lions). @from 2026-11-16T19:38:38 @conf 1 @source parser
```
