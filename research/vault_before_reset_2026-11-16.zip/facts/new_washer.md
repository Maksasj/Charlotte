# new_washer

```datalog
property(new_washer, price, cheap). @from 2026-11-16T20:30:47 @conf 1 @source teacher:chat
```
