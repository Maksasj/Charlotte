# armrest

```datalog
is_a(armrest, side_part). @from 2026-11-16T20:07:49 @conf 1 @source teacher:pretrain
part_of(armrest, chair). @from 2026-11-16T20:10:31 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:10:32
```
