# basement

```datalog
property(basement, size, small). @from 2026-11-16T20:28:59 @until 2026-11-16T20:32:22 @conf 1 @source teacher:chat
property(basement, quality, cool). @from 2026-11-16T20:28:59 @conf 1 @source teacher:chat
is_a(basement, cool_spot). @from 2026-11-16T20:29:12 @conf 1 @source teacher:chat
```
