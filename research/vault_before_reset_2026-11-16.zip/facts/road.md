# road

```datalog
property(road, quality, straight). @from 2026-11-16T20:25:49 @until 2026-11-16T20:28:06 @conf 1 @source teacher:chat
property(road, quality, flat). @from 2026-11-16T20:25:49 @conf 1 @source teacher:chat
property(road, quality, paved). @from 2026-11-16T20:27 @conf 1 @source teacher:chat
```
