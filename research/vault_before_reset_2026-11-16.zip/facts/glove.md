# glove

```datalog
go_on(glove, hand). @from 2026-11-16T20:12:18 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:12:18
has(glove, finger_part). @from 2026-11-16T20:12:18 @conf 1 @source teacher:pretrain
```
