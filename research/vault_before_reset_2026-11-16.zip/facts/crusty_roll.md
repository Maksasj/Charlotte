# crusty_roll

```datalog
property(crusty_roll, quality, plain). @from 2026-11-16T20:27:46 @conf 1 @source teacher:chat
property(crusty_roll, quality, crusty). @from 2026-11-16T20:27:46 @conf 1 @source teacher:chat
```
