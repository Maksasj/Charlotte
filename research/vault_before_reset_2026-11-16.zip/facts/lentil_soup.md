# lentil_soup

```datalog
is_a(lentil_soup, soup). @from 2026-11-16T20:25:20 @conf 1 @source teacher:chat
property(lentil_soup, quality, thick). @from 2026-11-16T20:25:20 @conf 1 @source teacher:chat
property(lentil_soup, quality, hearty). @from 2026-11-16T20:25:20 @conf 1 @source teacher:chat
```
