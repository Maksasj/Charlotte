# dead_sea

```datalog
proper_name(dead_sea). @from 2026-11-16T20:30:19 @conf 1 @source parser
is_a(dead_sea, salt_lake). @from 2026-11-16T20:30:19 @conf 1 @source teacher:chat
property(dead_sea, quality, salty). @from 2026-11-16T20:30:19 @conf 1 @source teacher:chat
```
