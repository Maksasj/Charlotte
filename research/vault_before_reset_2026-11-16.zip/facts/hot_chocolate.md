# hot_chocolate

```datalog
is_a(hot_chocolate, warm_drink). @from 2026-11-16T20:31:36 @conf 1 @source teacher:chat
```
