# americas

```datalog
proper_name(americas). @from 2026-11-16T19:21:46 @conf 1 @source parser
is_a(americas, both_continent). @from 2026-11-16T19:21:46 @until 2026-11-16T19:21:51 @conf 1 @source teacher:pretrain
```
