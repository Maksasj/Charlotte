# flat_side

```datalog
is_a(flat_side, face). @from 2026-11-16T20:05:14 @conf 1 @source teacher:pretrain
```
