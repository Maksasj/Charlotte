# liquid

```datalog
property(liquid, quality, sweet). @from 2026-11-16T20:30:03 @conf 1 @source teacher:chat
property(liquid, quality, sticky). @from 2026-11-16T20:30:03 @conf 1 @source teacher:chat
```
