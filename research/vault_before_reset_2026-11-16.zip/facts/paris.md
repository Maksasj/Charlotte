# paris

```datalog
proper_name(paris). @from 2026-11-16T19:15:02 @conf 1 @source parser
located_in(paris, france). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
is_a(paris, city). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:21:06
-located_in(paris, germany). @from 2026-11-16T19:20:55 @conf 1 @source teacher:pretrain
-is_a(paris, country). @from 2026-11-16T19:21:06 @conf 1 @source teacher:pretrain
is_a(paris, big_city). @from 2026-11-16T19:21:31 @conf 1 @source teacher:pretrain
is_a(paris, capital_city). @from 2026-11-16T19:47:12 @conf 1 @source teacher:pretrain
capital_of(paris, france). @from 2026-11-16T19:47:12 @conf 1 @source teacher:pretrain
has(paris, boulevard). @from 2026-11-16T20:28:56 @conf 1 @source teacher:chat
has(paris, cafe_culture). @from 2026-11-16T20:31:13 @conf 1 @source teacher:chat
```
