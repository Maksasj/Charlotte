# hospital

```datalog
located_in(hospital, city). @from 2026-11-16T19:16:21 @until 2026-11-16T19:16:30 @conf 1 @source teacher:pretrain
has(hospital, doctor). @from 2026-11-16T19:23:43 @conf 1 @source teacher:pretrain
has(hospital, many_kinds_of_worker). @from 2026-11-16T19:24:03 @conf 1 @source teacher:pretrain
has(hospital, nurse). @from 2026-11-16T19:24:06 @conf 1 @source teacher:pretrain
has(hospital, pharmacy). @from 2026-11-16T19:24:33 @conf 1 @source teacher:pretrain
proper_name(hospital). @from 2026-11-16T19:24:40 @conf 1 @source parser
is_a(hospital, place). @from 2026-11-16T20:12:05 @conf 1 @source teacher:pretrain
has(hospital, person). @from 2026-11-16T20:12:06 @conf 1 @source teacher:pretrain
has(hospital, paperwork_staff). @from 2026-11-16T20:29:23 @conf 1 @source teacher:chat
```
