# grass

```datalog
proper_name(grass). @from 2026-11-16T19:17:02 @conf 1 @source parser
is_a(grass, plant). @from 2026-11-16T19:17:02 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T19:26:09
property(grass, colour, green). @from 2026-11-16T19:17:02 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:22:38
```
