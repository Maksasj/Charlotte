# argentina

```datalog
proper_name(argentina). @from 2026-11-16T19:21:05 @conf 1 @source parser
located_in(argentina, south_america). @from 2026-11-16T19:21:05 @conf 1 @source teacher:pretrain
is_a(argentina, country). @from 2026-11-16T19:21:17 @conf 1 @source teacher:pretrain
speak(argentina, spanish). @from 2026-11-16T19:57:34 @conf 1 @source teacher:pretrain
capital(argentina, buenos_aires). @from 2026-11-16T20:00:05 @until 2026-11-16T20:03:07 @conf 1 @source teacher:pretrain
property(argentina, capital, buenos_aires). @from 2026-11-16T20:00:44 @conf 1 @source teacher:pretrain
```
