# delhi

```datalog
proper_name(delhi). @from 2026-11-16T19:20:47 @conf 1 @source parser
```
