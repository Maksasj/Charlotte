# computer

```datalog
is_a(computer, machine). @from 2026-11-16T19:25:22 @conf 1 @source teacher:pretrain
has(computer, keyboard). @from 2026-11-16T19:25:40 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:25:54
```
