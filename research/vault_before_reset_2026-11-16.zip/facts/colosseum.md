# colosseum

```datalog
proper_name(colosseum). @from 2026-11-16T19:47:46 @conf 1 @source parser
```
