# bread

```datalog
proper_name(bread). @from 2026-11-16T19:20:56 @conf 1 @source parser
is_a(bread, breakfast_food). @from 2026-11-16T19:20:56 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:53:22
```
