# fukuoka

```datalog
proper_name(fukuoka). @from 2026-11-16T20:30:43 @conf 1 @source parser
is_a(fukuoka, city). @from 2026-11-16T20:30:43 @conf 1 @source teacher:chat
located_in(fukuoka, kyushu). @from 2026-11-16T20:30:43 @conf 1 @source teacher:chat
```
