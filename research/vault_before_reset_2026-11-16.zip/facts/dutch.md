# dutch

```datalog
proper_name(dutch). @from 2026-11-16T20:25:49 @conf 1 @source parser
```
