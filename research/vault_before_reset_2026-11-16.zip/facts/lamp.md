# lamp

```datalog
located_in(lamp, room). @from 2026-11-16T19:15:59 @conf 1 @source teacher:pretrain
has(lamp, light). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
property(lamp, quality, bright). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
```
