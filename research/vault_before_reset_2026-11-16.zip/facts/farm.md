# farm

```datalog
property(farm, size, big). @from 2026-11-16T19:16:21 @conf 1 @source teacher:pretrain
proper_name(farm). @from 2026-11-16T19:19:11 @conf 1 @source parser
```
