# quiet

```datalog
proper_name(quiet). @from 2026-11-16T20:25:23 @conf 1 @source parser
```
