# human

```datalog
has(human, hand). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
is_a(human, animal). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:40
is_a(human, mammal). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
has(human, two_arm). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
has(human, two_leg). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
has(human, ten_finger). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
has(human, ten_toe). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
has(human, heart). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
has(human, brain). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
has(human, lung). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
has(human, skeleton). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
has(human, eye). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
```
