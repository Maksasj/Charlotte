# ganymede

```datalog
proper_name(ganymede). @from 2026-11-16T20:27:21 @conf 1 @source parser
is_a(ganymede, moon). @from 2026-11-16T20:27:21 @conf 1 @source teacher:chat
larger_than(ganymede, mercury). @from 2026-11-16T20:27:21 @conf 1 @source teacher:chat
part_of(ganymede, jupiter). @from 2026-11-16T20:27:39 @until 2026-11-16T20:28:06 @conf 1 @source teacher:chat
property(ganymede, size, big). @from 2026-11-16T20:27:39 @until 2026-11-16T20:27:55 @conf 1 @source teacher:chat
property(ganymede, size, biggest). @from 2026-11-16T20:27:55 @conf 1 @source teacher:chat
property(ganymede, quality, biggest_moon). @from 2026-11-16T20:27:55 @conf 1 @source teacher:chat
```
