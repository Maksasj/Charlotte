# france

```datalog
proper_name(france). @from 2026-11-16T19:15:02 @conf 1 @source parser
located_in(france, europe). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:20:22
is_a(france, country). @from 2026-11-16T19:20:03 @conf 1 @source teacher:pretrain
property(france, capital, paris). @from 2026-11-16T19:46:39 @conf 1 @source teacher:pretrain
```
