# plane

```datalog
is_a(plane, vehicle). @from 2026-11-16T19:24:16 @conf 1 @source teacher:pretrain
has(plane, wing). @from 2026-11-16T19:24:23 @conf 1 @source teacher:pretrain
has(plane, engine). @from 2026-11-16T19:24:59 @conf 1 @source teacher:pretrain
give(plane, view). @from 2026-11-16T20:30:19 @conf 1 @source teacher:chat
```
