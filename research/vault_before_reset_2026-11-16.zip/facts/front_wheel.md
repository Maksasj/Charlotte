# front_wheel

```datalog
turn(front_wheel). @from 2026-11-16T20:15:17 @conf 1 @source teacher:pretrain
steer(front_wheel, car). @from 2026-11-16T20:17:33 @conf 1 @source teacher:pretrain
steer(front_wheel). @from 2026-11-16T20:25:17 @conf 1 @source teacher:chat
balance(front_wheel, bike). @from 2026-11-16T20:25:17 @conf 1 @source teacher:chat
```
