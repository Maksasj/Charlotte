# china

```datalog
proper_name(china). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(china, asia). @from 2026-11-16T19:20:03 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:20:23
is_a(china, country). @from 2026-11-16T19:20:20 @conf 1 @source teacher:pretrain
property(china, size, big). @from 2026-11-16T19:48:27 @conf 1 @source teacher:pretrain
property(china, capital, beijing). @from 2026-11-16T19:53:15 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:54:09
```
