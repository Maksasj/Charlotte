# mount_everest

```datalog
proper_name(mount_everest). @from 2026-11-16T20:02:22 @conf 1 @source parser
is_a(mount_everest, mountain). @from 2026-11-16T20:02:33 @conf 1 @source teacher:pretrain
```
