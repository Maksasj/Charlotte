# pliers

```datalog
grip(pliers, small_thing). @from 2026-11-16T20:10:19 @conf 1 @source teacher:pretrain
```
