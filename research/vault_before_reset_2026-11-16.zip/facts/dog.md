# dog

```datalog
is_a(dog, animal). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:19:40
has(dog, four_leg). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
has(dog, blood). @from 2026-11-16T19:18:40 @conf 1 @source teacher:pretrain
is_a(dog, pet). @from 2026-11-16T19:19:04 @conf 1 @source teacher:pretrain
has(dog, feather). @from 2026-11-16T19:19:29 @until 2026-11-16T19:19:55 @conf 1 @source teacher:pretrain
has(dog, fur). @from 2026-11-16T19:19:35 @conf 1 @source teacher:pretrain
live_with(dog, person). @from 2026-11-16T19:36:59 @conf 1 @source teacher:pretrain
located_in(dog, people). @from 2026-11-16T19:37:38 @until 2026-11-16T19:46:04 @conf 1 @source teacher:pretrain
came_from(dog, wolf). @until 2026-11-16T19:37:38 @conf 1 @source teacher:pretrain
call(dog, man_best_friend). @from 2026-11-16T19:42:05 @until 2026-11-16T19:46:04 @conf 1 @source teacher:pretrain
come_from(dog, wolf). @from 2026-11-16T19:43:40 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:43:40
wants(dog, walk). @from 2026-11-16T20:24:50 @conf 1 @source teacher:chat
wants(dog, regular_feeding). @from 2026-11-16T20:24:50 @conf 1 @source teacher:chat
wants(dog, company). @from 2026-11-16T20:24:50 @conf 1 @source teacher:chat
wants(dog, go_out). @from 2026-11-16T20:25:21 @conf 1 @source teacher:chat
play(dog). @from 2026-11-16T20:25:21 @conf 1 @source teacher:chat
```
