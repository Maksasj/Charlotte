# cube

```datalog
is_a(cube, box). @from 2026-11-16T20:09:31 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:10:12
has(cube, face). @from 2026-11-16T20:10:41 @conf 1 @source teacher:pretrain
has(cube, corner). @from 2026-11-16T20:10:41 @conf 1 @source teacher:pretrain
has(cube, six_face). @from 2026-11-16T20:10:41 @conf 1 @source teacher:pretrain
```
