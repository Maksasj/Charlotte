# park

```datalog
is_a(park, green_spot). @from 2026-11-16T20:27:47 @conf 1 @source teacher:chat
located_in(park, city). @from 2026-11-16T20:27:47 @conf 1 @source teacher:chat
```
