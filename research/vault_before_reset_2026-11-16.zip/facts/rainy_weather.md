# rainy_weather

```datalog
wear(rainy_weather, waterproof_jacket). @from 2026-11-16T20:56:06 @conf 1 @source teacher:train
wear(rainy_weather, warm_sweater). @from 2026-11-16T20:56:06 @conf 1 @source teacher:train
wear(rainy_weather, closed_shoe). @from 2026-11-16T20:56:06 @conf 1 @source teacher:train
bring(rainy_weather, umbrella). @from 2026-11-16T20:56:06 @conf 1 @source teacher:train
```
