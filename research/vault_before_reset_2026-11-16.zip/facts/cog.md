# cog

```datalog
is_a(cog, gear). @from 2026-11-16T20:16:11 @conf 1 @source teacher:pretrain
is_a(cog, small_gear). @from 2026-11-16T20:16:57 @conf 1 @source teacher:pretrain
```
