# london

```datalog
proper_name(london). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(london, england). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
is_a(london, big_city). @from 2026-11-16T19:22:11 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:22:11
is_a(london, european_city). @from 2026-11-16T20:31:37 @conf 1 @source teacher:chat
```
