# leaf

```datalog
part_of(leaf, tree). @from 2026-11-16T19:17:02 @conf 1 @source teacher:pretrain
property(leaf, colour, green). @from 2026-11-16T20:25:40 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:25:41
```
