# peru

```datalog
proper_name(peru). @from 2026-11-16T19:21:39 @conf 1 @source parser
located_in(peru, south_america). @from 2026-11-16T19:21:39 @conf 1 @source teacher:pretrain
```
