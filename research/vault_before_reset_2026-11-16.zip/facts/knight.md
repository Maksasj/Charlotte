# knight

```datalog
jump_in(knight, l_shape). @from 2026-11-16T20:26:13 @conf 1 @source teacher:chat
move(knight, l_shape). @from 2026-11-16T20:26:32 @conf 1 @source teacher:chat
```
