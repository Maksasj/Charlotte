# french

```datalog
proper_name(french). @from 2026-11-16T19:51:41 @conf 1 @source parser
```
