# bathroom

```datalog
is_a(bathroom, room). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
has(bathroom, sink). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
```
