# cold_weather

```datalog
snow(cold_weather). @from 2026-11-16T20:25:07 @until 2026-11-16T20:28:09 @conf 1 @source teacher:chat
```
