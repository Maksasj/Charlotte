# bedroom

```datalog
is_a(bedroom, room). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
has(bedroom, bed). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
has(bedroom, closet). @from 2026-11-16T20:11:05 @conf 1 @source teacher:pretrain
```
