# lentil

```datalog
property(lentil, quality, soft). @from 2026-11-16T20:25:20 @conf 1 @source teacher:chat
is_a(lentil, seed). @from 2026-11-16T20:25:36 @conf 1 @source teacher:chat
```
