# biggest_planet

```datalog
is_a(biggest_planet, giant_ball_of_gas). @from 2026-11-16T20:25:48 @conf 1 @source teacher:chat
property(biggest_planet, size, huge). @from 2026-11-16T20:25:48 @conf 1 @source teacher:chat
```
