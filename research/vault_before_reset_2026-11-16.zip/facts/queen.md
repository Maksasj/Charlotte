# queen

```datalog
move(queen, straight). @from 2026-11-16T20:26:32 @conf 1 @source teacher:chat
move(queen, diagonal). @from 2026-11-16T20:26:32 @conf 1 @source teacher:chat
property(queen, quality, strongest). @from 2026-11-16T20:26:32 @conf 1 @source teacher:chat
```
