# orange

```datalog
property(orange, quality, fruit). @from 2026-11-16T19:19:29 @conf 1 @source teacher:pretrain
-is_a(orange, vegetable). @from 2026-11-16T19:19:36 @conf 1 @source teacher:pretrain
```
