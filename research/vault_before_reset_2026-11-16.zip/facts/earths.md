# earths

```datalog
proper_name(earths). @from 2026-11-16T20:26:03 @conf 1 @source parser
```
