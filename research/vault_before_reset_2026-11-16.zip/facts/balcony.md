# balcony

```datalog
property(balcony, size, small). @from 2026-11-16T20:56:30 @conf 1 @source teacher:train
get(balcony, sun). @from 2026-11-16T20:56:30 @conf 1 @source teacher:train
```
