# police_officer

```datalog
property(police_officer, job, to_protect_people). @from 2026-11-16T19:16:21 @conf 1 @source teacher:pretrain
```
