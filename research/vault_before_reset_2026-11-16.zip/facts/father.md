# father

```datalog
is_a(father, male_parent). @from 2026-11-16T19:26:35 @conf 1 @source teacher:pretrain
is_a(father, parent). @from 2026-11-16T19:26:47 @conf 1 @source teacher:pretrain
-is_a(father, child). @from 2026-11-16T19:27:20 @conf 1 @source teacher:pretrain
```
