# porter

```datalog
is_a(porter, person). @from 2026-11-16T20:30:27 @conf 1 @source teacher:chat
move(porter, patient). @from 2026-11-16T20:30:27 @conf 1 @source teacher:chat
use(porter, bed). @from 2026-11-16T20:30:27 @conf 1 @source teacher:chat
use(porter, wheelchair). @from 2026-11-16T20:30:27 @conf 1 @source teacher:chat
```
