# chart

```datalog
is_a(chart, file). @from 2026-11-16T20:15:41 @conf 1 @source teacher:pretrain
is_a(chart, record). @from 2026-11-16T20:17:11 @conf 1 @source teacher:pretrain
```
