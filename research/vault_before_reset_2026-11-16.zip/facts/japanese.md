# japanese

```datalog
proper_name(japanese). @from 2026-11-16T20:25:06 @conf 1 @source parser
```
