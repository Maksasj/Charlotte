# crusty_bread_roll

```datalog
eat_with(crusty_bread_roll, cold_meat). @from 2026-11-16T20:27:09 @conf 1 @source teacher:chat
eat_with(crusty_bread_roll, cheese). @from 2026-11-16T20:27:09 @conf 1 @source teacher:chat
eat_with(crusty_bread_roll, cucumber). @from 2026-11-16T20:27:09 @conf 1 @source teacher:chat
```
