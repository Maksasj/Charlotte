# horse

```datalog
is_a(horse, mammal). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain
property(horse, size, big). @from 2026-11-16T19:22:35 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:22:40
```
