# golf

```datalog
proper_name(golf). @from 2026-11-16T19:25:23 @conf 1 @source parser
is_a(golf, sport). @from 2026-11-16T19:25:23 @conf 1 @source teacher:pretrain
```
