# lettuce

```datalog
cope_with(lettuce, sun). @from 2026-11-16T21:07:54 @conf 1 @source teacher:train
grow_in(lettuce, pot). @from 2026-11-16T21:07:54 @conf 1 @source teacher:train
pick(lettuce, outer_leaf). @from 2026-11-16T21:07:54 @conf 1 @source teacher:train
```
