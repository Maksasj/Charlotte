# chef

```datalog
cook(chef, food_in_restaurant). @from 2026-11-16T19:24:32 @conf 1 @source teacher:pretrain
cook(chef, food). @from 2026-11-16T19:24:43 @conf 1 @source teacher:pretrain
work_in(chef, restaurant). @from 2026-11-16T19:25:14 @conf 1 @source teacher:pretrain
```
