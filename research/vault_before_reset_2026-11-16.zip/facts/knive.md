# knive

```datalog
property(knive, quality, sharp). @from 2026-11-16T19:15:59 @conf 1 @source teacher:pretrain
```
