# blossom

```datalog
property(blossom, colour, pink). @from 2026-11-16T20:28:10 @conf 1 @source teacher:chat
property(blossom, quality, cloud_like). @from 2026-11-16T20:28:28 @conf 1 @source teacher:chat
property(blossom, size, small). @from 2026-11-16T20:29:22 @conf 1 @source teacher:chat
```
