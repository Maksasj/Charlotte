# mercury

```datalog
proper_name(mercury). @from 2026-11-16T20:00:29 @conf 1 @source parser
is_a(mercury, planet). @from 2026-11-16T20:01:18 @conf 1 @source teacher:pretrain
property(mercury, order_from_sun, first). @from 2026-11-16T20:02:48 @conf 1 @source teacher:pretrain
property(mercury, quality, nearest_to_sun). @from 2026-11-16T20:25:33 @conf 1 @source teacher:chat
property(mercury, quality, closest_to_sun). @from 2026-11-16T20:25:48 @conf 1 @source teacher:chat
```
