# radish

```datalog
grow_under(radish, ground). @from 2026-11-16T19:47:18 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:50:28
property(radish, size, small). @from 2026-11-16T19:48:46 @conf 1 @source teacher:pretrain
property(radish, colour, red). @from 2026-11-16T19:48:46 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:30:42
proper_name(radish). @from 2026-11-16T20:57:51 @conf 1 @source parser
```
