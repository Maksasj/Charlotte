# harbour

```datalog
is_a(harbour, coast). @from 2026-11-16T19:55:12 @until 2026-11-16T19:55:38 @conf 1 @source teacher:pretrain
```
