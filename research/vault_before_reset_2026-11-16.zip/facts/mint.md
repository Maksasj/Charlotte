# mint

```datalog
is_a(mint, herb). @from 2026-11-16T20:57:07 @conf 1 @source teacher:train
property(mint, quality, easy). @from 2026-11-16T20:57:07 @conf 1 @source teacher:train
wants(mint, water). @from 2026-11-16T20:57:07 @conf 1 @source teacher:train
proper_name(mint). @from 2026-11-16T21:07:40 @conf 1 @source parser
cope_with(mint, sun). @from 2026-11-16T21:07:54 @conf 1 @source teacher:train
grow_in(mint, pot). @from 2026-11-16T21:07:54 @conf 1 @source teacher:train
spread(mint). @from 2026-11-16T21:07:54 @conf 1 @source teacher:train
```
