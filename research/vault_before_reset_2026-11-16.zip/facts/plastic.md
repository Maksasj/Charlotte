# plastic

```datalog
proper_name(plastic). @from 2026-11-16T19:25:37 @conf 1 @source parser
is_a(plastic, material). @from 2026-11-16T19:25:37 @conf 1 @source teacher:pretrain
come_from(plastic, oil). @from 2026-11-16T19:26:19 @conf 1 @source teacher:pretrain
```
