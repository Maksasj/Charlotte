# clear_water

```datalog
look_like(clear_water, glass). @from 2026-11-16T20:27:25 @conf 1 @source teacher:chat
see(clear_water, stone). @from 2026-11-16T20:27:25 @until 2026-11-16T20:27:55 @conf 1 @source teacher:chat
```
