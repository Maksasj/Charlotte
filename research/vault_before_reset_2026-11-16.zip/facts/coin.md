# coin

```datalog
property(coin, quality, round). @from 2026-11-16T19:23:26 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:05:48
```
