# cell

```datalog
property(cell, size, small). @from 2026-11-16T19:25:50 @until 2026-11-16T19:25:57 @conf 1 @source teacher:pretrain
property(cell, size, tiny). @from 2026-11-16T19:25:57 @conf 1 @source teacher:pretrain
```
