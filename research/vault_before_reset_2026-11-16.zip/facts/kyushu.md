# kyushu

```datalog
proper_name(kyushu). @from 2026-11-16T19:49:55 @conf 1 @source parser
is_a(kyushu, island). @from 2026-11-16T19:50:03 @conf 1 @source teacher:pretrain
located_in(kyushu, japan). @from 2026-11-16T20:30:43 @conf 1 @source teacher:chat
part_of(kyushu, japan). @from 2026-11-16T20:31:33 @conf 1 @source teacher:chat
```
