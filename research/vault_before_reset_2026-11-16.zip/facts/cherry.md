# cherry

```datalog
property(cherry, colour, red). @from 2026-11-16T19:22:41 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T20:30:42
red(cherry). @from 2026-11-16T20:05:40 @conf 1 @source teacher:pretrain
is_a(cherry, fruit). @from 2026-11-16T20:31:23 @conf 1 @source teacher:chat
```
