# can

```datalog
proper_name(can). @from 2026-11-16T19:39:54 @conf 1 @source parser
```
