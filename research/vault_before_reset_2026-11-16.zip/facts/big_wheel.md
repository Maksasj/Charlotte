# big_wheel

```datalog
located_in(big_wheel, back). @from 2026-11-16T20:30:49 @conf 1 @source teacher:chat
```
