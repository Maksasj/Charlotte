# fact_to_check

```datalog
cook(fact_to_check, works_in_restaurant). @from 2026-11-16T19:25:05 @until 2026-11-16T19:25:29 @conf 1 @source teacher:pretrain
```
