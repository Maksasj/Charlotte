# potato

```datalog
is_a(potato, vegetable). @from 2026-11-16T19:20:35 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T19:23:12
grow_under(potato, ground). @from 2026-11-16T19:46:47 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:50:28
-property(potato, colour, orange). @from 2026-11-16T19:46:47 @conf 1 @source teacher:pretrain
property(potato, colour, brown). @from 2026-11-16T19:50:28 @conf 1 @source teacher:pretrain
-is_a(potato, root). @from 2026-11-16T19:52:49 @conf 1 @source teacher:pretrain
is_a(potato, tuber). @from 2026-11-16T19:52:49 @conf 1 @source teacher:pretrain
is_a(potato, cousin). @from 2026-11-16T20:25:09 @until 2026-11-16T20:27:47 @conf 1 @source teacher:chat
is_a(potato, nightshade). @from 2026-11-16T20:25:26 @conf 1 @source teacher:chat
```
