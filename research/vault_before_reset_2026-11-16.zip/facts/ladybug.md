# ladybug

```datalog
is_a(ladybug, beetle). @from 2026-11-16T20:31:23 @conf 1 @source teacher:chat
property(ladybug, quality, round). @from 2026-11-16T20:31:23 @conf 1 @source teacher:chat
has(ladybug, shell). @from 2026-11-16T20:31:23 @conf 1 @source teacher:chat
has(ladybug, spot). @from 2026-11-16T20:31:23 @conf 1 @source teacher:chat
located_in(ladybug, plant). @from 2026-11-16T20:31:23 @conf 1 @source teacher:chat
feast_on(ladybug, aphid). @from 2026-11-16T20:31:23 @conf 1 @source teacher:chat
```
