# roasting

```datalog
proper_name(roasting). @from 2026-11-16T20:26:25 @conf 1 @source parser
property(roasting, quality, easy). @from 2026-11-16T20:26:25 @conf 1 @source teacher:chat
property(roasting, quality, easy_to_mess_up). @from 2026-11-16T20:26:36 @conf 1 @source teacher:chat
```
