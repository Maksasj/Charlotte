# milk

```datalog
proper_name(milk). @from 2026-11-16T19:15:24 @conf 1 @source parser
is_a(milk, drink). @from 2026-11-16T19:15:24 @conf 1 @source teacher:pretrain
property(milk, colour, white). @from 2026-11-16T19:15:24 @conf 1 @source teacher:pretrain
is_a(milk, breakfast_drink). @from 2026-11-16T19:20:24 @conf 1 @source teacher:pretrain
property(milk, quality, tangy). @from 2026-11-16T19:48:20 @until 2026-11-16T19:48:20 @conf 1 @source teacher:pretrain
property(milk, quality, fizzy). @from 2026-11-16T19:48:20 @until 2026-11-16T19:49:03 @conf 1 @source teacher:pretrain
-property(milk, quality, tangy). @from 2026-11-16T19:49:03 @until 2026-11-16T19:49:03 @conf 1 @source teacher:pretrain
-property(milk, quality, fizzy). @from 2026-11-16T19:49:03 @until 2026-11-16T19:49:03 @conf 1 @source teacher:pretrain
property(milk, quality, tangy). @from 2026-11-16T19:49:03 @until 2026-11-16T19:49:03 @conf 1 @source teacher:pretrain
property(milk, quality, fizzy). @from 2026-11-16T19:49:03 @until 2026-11-16T19:55:12 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:49:03
-change(milk). @from 2026-11-16T19:49:55 @until 2026-11-16T19:55:12 @conf 1 @source teacher:pretrain
turn_into(milk, kefir). @from 2026-11-16T19:53:07 @conf 1 @source teacher:pretrain
```
