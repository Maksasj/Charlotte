# most

```datalog
proper_name(most). @from 2026-11-16T19:46:13 @conf 1 @source parser
```
