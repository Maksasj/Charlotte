# red_spot

```datalog
is_a(red_spot, storm). @from 2026-11-16T20:26:19 @conf 1 @source teacher:chat
swirl(red_spot). @from 2026-11-16T20:26:39 @conf 1 @source teacher:chat
property(red_spot, quality, bigger_than_earth). @from 2026-11-16T20:26:39 @conf 1 @source teacher:chat
```
