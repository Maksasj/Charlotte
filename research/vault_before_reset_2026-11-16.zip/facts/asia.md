# asia

```datalog
proper_name(asia). @from 2026-11-16T19:15:42 @conf 1 @source parser
is_a(asia, large_continent). @from 2026-11-16T19:20 @conf 1 @source teacher:pretrain
has(asia, many_country). @from 2026-11-16T19:20:03 @conf 1 @source teacher:pretrain
is_a(asia, continent). @from 2026-11-16T19:47:38 @conf 1 @source teacher:pretrain
has(asia, country). @from 2026-11-16T19:48:27 @conf 1 @source teacher:pretrain
```
