# all

```datalog
proper_name(all). @from 2026-11-16T21:05:14 @conf 1 @source parser
```
