# country

```datalog
has(country, border). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
is_a(country, place). @from 2026-11-16T19:20:03 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:49:10
has(country, capital_city). @from 2026-11-16T19:20:35 @conf 1 @source teacher:pretrain
has(country, big_city). @from 2026-11-16T19:21:25 @conf 1 @source teacher:pretrain
property(country, quality, quiet). @from 2026-11-16T20:24:28 @conf 1 @source teacher:chat
```
