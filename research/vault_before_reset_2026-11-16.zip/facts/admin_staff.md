# admin_staff

```datalog
keep(admin_staff, record). @from 2026-11-16T20:29:45 @conf 1 @source teacher:chat
```
