# engine

```datalog
part_of(engine, car). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain
```
