# fire_engine

```datalog
property(fire_engine, colour, red). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:30:42
```
