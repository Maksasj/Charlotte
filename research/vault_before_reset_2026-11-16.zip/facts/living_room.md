# living_room

```datalog
is_a(living_room, room). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
property(living_room, quality, rooms). @from 2026-11-16T19:17:33 @until 2026-11-16T19:17:44 @conf 1 @source teacher:pretrain
has(living_room, sofa). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
```
