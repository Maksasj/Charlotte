# gas_giant

```datalog
is_a(gas_giant, ball). @from 2026-11-16T20:26:19 @conf 1 @source teacher:chat
property(gas_giant, size, huge). @from 2026-11-16T20:26:19 @conf 1 @source teacher:chat
-has(gas_giant, solid_surface). @from 2026-11-16T20:26:19 @conf 1 @source teacher:chat
-has(gas_giant, solid_ground). @from 2026-11-16T20:26:39 @conf 1 @source teacher:chat
```
