# national_diet_building

```datalog
proper_name(national_diet_building). @from 2026-11-16T20:01:34 @conf 1 @source parser
is_a(national_diet_building, building). @from 2026-11-16T20:01:42 @conf 1 @source teacher:pretrain
located_in(national_diet_building, tokyo). @from 2026-11-16T20:01:42 @conf 1 @source teacher:pretrain
```
