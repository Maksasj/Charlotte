# head

```datalog
part_of(head, insect). @from 2026-11-16T19:40:08 @conf 1 @source teacher:pretrain
is_a(head, body_part). @from 2026-11-16T19:42:58 @conf 1 @source teacher:pretrain
```
