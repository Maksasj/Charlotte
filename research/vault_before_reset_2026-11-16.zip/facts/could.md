# could

```datalog
proper_name(could). @from 2026-11-16T20:57:39 @conf 1 @source parser
```
