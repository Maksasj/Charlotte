# one

```datalog
proper_name(one). @from 2026-11-16T21:05:52 @conf 1 @source parser
```
