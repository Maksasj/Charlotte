# river

```datalog
property(river, quality, fresh). @from 2026-11-16T19:21:46 @conf 1 @source teacher:pretrain
has(river, fresh_water). @from 2026-11-16T19:22:09 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:01:48
is_a(river, fresh_water). @from 2026-11-16T20:00:21 @conf 1 @source teacher:pretrain
carry(river, fresh_water). @from 2026-11-16T20:00:22 @conf 1 @source teacher:pretrain
start_in(river, mountain). @from 2026-11-16T20:00:22 @conf 1 @source teacher:pretrain
begin_in(river, mountain). @from 2026-11-16T20:02:33 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:02:33
is_a(river, water). @from 2026-11-16T20:28:50 @conf 1 @source teacher:chat
flow_toward(river, lake). @from 2026-11-16T20:28:50 @conf 1 @source teacher:chat
flow_toward(river, sea). @from 2026-11-16T20:28:50 @conf 1 @source teacher:chat
run_into(river, lake). @from 2026-11-16T20:29:09 @conf 1 @source teacher:chat
run_out_of(river, lake). @from 2026-11-16T20:29:09 @conf 1 @source teacher:chat
```
