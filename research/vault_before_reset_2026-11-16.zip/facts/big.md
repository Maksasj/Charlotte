# big

```datalog
proper_name(big). @from 2026-11-16T19:21:12 @conf 1 @source parser
```
