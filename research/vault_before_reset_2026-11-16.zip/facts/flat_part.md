# flat_part

```datalog
is_a(flat_part, seat). @from 2026-11-16T20:09:19 @until 2026-11-16T20:11:28 @conf 1 @source teacher:pretrain
is_a(flat_part, steering_wheel). @from 2026-11-16T20:12:26 @conf 1 @source teacher:pretrain
property(flat_part, quality, round). @from 2026-11-16T20:12:26 @conf 1 @source teacher:pretrain
```
