# bus

```datalog
is_a(bus, vehicle). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain
has(bus, window). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain
```
