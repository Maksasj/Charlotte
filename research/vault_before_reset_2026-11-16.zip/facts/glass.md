# glass

```datalog
proper_name(glass). @from 2026-11-16T19:25:27 @conf 1 @source parser
is_a(glass, material). @from 2026-11-16T19:25:27 @conf 1 @source teacher:pretrain
-is_a(glass, metal). @from 2026-11-16T19:26:02 @conf 1 @source teacher:pretrain
come_from(glass, sand). @from 2026-11-16T19:26:08 @conf 1 @source teacher:pretrain
-is_a(glass, plastic). @from 2026-11-16T19:26:19 @conf 1 @source teacher:pretrain
```
