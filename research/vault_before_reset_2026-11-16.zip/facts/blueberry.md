# blueberry

```datalog
property(blueberry, colour, blue). @from 2026-11-16T20:07:55 @conf 1 @source teacher:pretrain
is_a(blueberry, blue_thing). @from 2026-11-16T20:08:37 @conf 1 @source teacher:pretrain
property(blueberry, quality, juicy). @from 2026-11-16T20:25:20 @conf 1 @source teacher:chat
burst(blueberry). @from 2026-11-16T20:25:20 @conf 1 @source teacher:chat
proper_name(blueberry). @from 2026-11-16T20:25:53 @conf 1 @source parser
```
