# angry

```datalog
proper_name(angry). @from 2026-11-16T19:27:23 @conf 1 @source parser
is_a(angry, feeling). @from 2026-11-16T19:27:23 @conf 1 @source teacher:pretrain
```
