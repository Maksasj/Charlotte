# hemoglobin

```datalog
is_a(hemoglobin, protein). @from 2026-11-16T20:29:49 @conf 1 @source teacher:chat
grab_onto(hemoglobin, oxygen). @from 2026-11-16T20:29:49 @conf 1 @source teacher:chat
located_in(hemoglobin, red_blood_cell). @from 2026-11-16T20:30:13 @conf 1 @source teacher:chat
grab(hemoglobin, oxygen). @from 2026-11-16T20:30:13 @conf 1 @source teacher:chat
```
