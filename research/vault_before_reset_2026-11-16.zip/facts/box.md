# box

```datalog
property(box, quality, square). @from 2026-11-16T19:22:46 @until 2026-11-16T19:23:39 @conf 1 @source teacher:pretrain
hold(box, thing). @from 2026-11-16T19:23:32 @conf 1 @source teacher:pretrain
property(box, shape, rectangular_prism). @from 2026-11-16T20:04:03 @conf 1 @source teacher:pretrain
is_a(box, rectangular_prism). @from 2026-11-16T20:04:35 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:15:34
has(box, corner). @from 2026-11-16T20:05:14 @conf 1 @source teacher:pretrain @uses 4 @last 2026-11-16T20:10:12
has(box, face). @from 2026-11-16T20:08:45 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T20:10:12
property(box, name, penalty_area). @from 2026-11-16T20:16:19 @conf 1 @source teacher:pretrain
is_a(box, rectangle). @from 2026-11-16T20:16:19 @conf 1 @source teacher:pretrain
```
