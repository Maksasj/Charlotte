# chess

```datalog
proper_name(chess). @from 2026-11-16T20:25:58 @conf 1 @source parser
is_a(chess, game). @from 2026-11-16T20:26:13 @conf 1 @source teacher:chat
property(chess, goal, checkmate). @from 2026-11-16T20:26:13 @conf 1 @source teacher:chat
```
