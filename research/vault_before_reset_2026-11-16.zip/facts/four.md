# four

```datalog
proper_name(four). @from 2026-11-16T19:21:28 @conf 1 @source parser
```
