# kenya

```datalog
proper_name(kenya). @from 2026-11-16T19:15:42 @conf 1 @source parser
```
