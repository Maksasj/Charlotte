# blood_pressure

```datalog
is_a(blood_pressure, vital_sign). @from 2026-11-16T20:14:50 @conf 1 @source teacher:pretrain
```
