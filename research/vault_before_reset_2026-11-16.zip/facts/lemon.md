# lemon

```datalog
property(lemon, colour, yellow). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T20:05:07
property(lemon, quality, sour). @from 2026-11-16T19:15:24 @until 2026-11-16T19:18:58 @conf 1 @source teacher:pretrain
property(lemon, quality, fruit). @from 2026-11-16T19:18:58 @conf 1 @source teacher:pretrain
is_a(lemon, fruit). @from 2026-11-16T19:19:57 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:26:09
grow_on(lemon, lemon_tree). @from 2026-11-16T20:31:35 @conf 1 @source teacher:chat
```
