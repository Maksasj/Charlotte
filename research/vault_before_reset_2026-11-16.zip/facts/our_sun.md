# our_sun

```datalog
is_a(our_sun, star). @from 2026-11-16T19:21:20 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:05:48
```
