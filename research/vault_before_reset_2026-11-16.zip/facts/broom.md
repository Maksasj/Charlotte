# broom

```datalog
property(broom, colour, brown). @from 2026-11-16T19:15:59 @until 2026-11-16T19:16:07 @conf 1 @source teacher:pretrain
```
