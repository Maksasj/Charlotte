# hat_can

```datalog
proper_name(hat_can). @from 2026-11-16T21:11:42 @conf 1 @source parser
```
