# new_delhi

```datalog
is_a(new_delhi, capital_of_india). @from 2026-11-16T19:20:47 @conf 1 @source teacher:pretrain
```
