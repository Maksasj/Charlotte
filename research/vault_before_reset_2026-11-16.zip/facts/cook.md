# cook

```datalog
use(cook, knive). @from 2026-11-16T19:20:02 @conf 1 @source teacher:pretrain
work_in(cook, restaurant). @from 2026-11-16T19:24:05 @conf 1 @source teacher:pretrain
make(cook, food_in_kitchen). @from 2026-11-16T19:24:21 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:26:09
proper_name(cook). @from 2026-11-16T19:24:47 @conf 1 @source parser
make(cook, food). @from 2026-11-16T20:15:09 @conf 1 @source teacher:pretrain
```
