# boil

```datalog
proper_name(boil). @from 2026-11-16T21:00:57 @conf 1 @source parser
```
