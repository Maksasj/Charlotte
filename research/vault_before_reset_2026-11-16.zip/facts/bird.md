# bird

```datalog
has(bird, wing). @from 2026-11-16T19:15:02 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:24
is_a(bird, animal). @from 2026-11-16T19:18:34 @conf 1 @source teacher:pretrain @uses 5 @last 2026-11-16T19:20:14
has(bird, feather). @from 2026-11-16T19:18:42 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:24
has(bird, beak). @from 2026-11-16T19:18:45 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:24
proper_name(bird). @from 2026-11-16T19:18:48 @conf 1 @source parser
has(bird, heart). @from 2026-11-16T19:18:58 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:24
has(bird, two_leg). @from 2026-11-16T19:19:34 @conf 1 @source teacher:pretrain
is_a(bird, animal_with_feathers). @from 2026-11-16T19:37:21 @conf 1 @source teacher:pretrain
has(bird, hollow_bone). @from 2026-11-16T19:39:48 @conf 1 @source teacher:pretrain
property(bird, quality, light). @from 2026-11-16T19:41:07 @conf 1 @source teacher:pretrain
located_in(bird, branch). @from 2026-11-16T20:25:08 @conf 1 @source teacher:chat
```
