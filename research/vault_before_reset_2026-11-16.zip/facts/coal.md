# coal

```datalog
proper_name(coal). @from 2026-11-16T19:22:29 @conf 1 @source parser
property(coal, colour, black). @from 2026-11-16T19:22:29 @conf 1 @source teacher:pretrain
```
