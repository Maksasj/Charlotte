# oven

```datalog
is_a(oven, box). @from 2026-11-16T19:51:22 @conf 1 @source teacher:pretrain
cook(oven, food). @from 2026-11-16T19:51:22 @conf 1 @source teacher:pretrain
```
