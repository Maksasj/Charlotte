# airplane

```datalog
is_a(airplane, vehicle). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain
has(airplane, wing). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain
```
