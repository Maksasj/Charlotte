# emperor_of_japan

```datalog
located_in(emperor_of_japan, tokyo). @from 2026-11-16T20:00:17 @conf 1 @source teacher:pretrain
```
