# face

```datalog
is_a(face, square). @from 2026-11-16T20:10:41 @until 2026-11-16T20:11:11 @conf 1 @source teacher:pretrain
property(face, size, same). @from 2026-11-16T20:10:42 @until 2026-11-16T20:11:11 @conf 1 @source teacher:pretrain
```
