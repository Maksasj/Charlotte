# geography

```datalog
proper_name(geography). @from 2026-11-16T19:26:07 @conf 1 @source parser
is_a(geography, school_subject). @from 2026-11-16T19:26:07 @conf 1 @source teacher:pretrain
```
