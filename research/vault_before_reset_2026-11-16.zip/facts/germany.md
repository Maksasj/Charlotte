# germany

```datalog
proper_name(germany). @from 2026-11-16T19:15:02 @conf 1 @source parser
is_a(germany, country). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
located_in(germany, europe). @from 2026-11-16T19:20:22 @conf 1 @source teacher:pretrain
property(germany, capital, berlin). @from 2026-11-16T19:49:24 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:50:18
property(germany, biggest_city, berlin). @from 2026-11-16T19:49:24 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:50:18
```
