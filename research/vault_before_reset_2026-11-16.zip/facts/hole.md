# hole

```datalog
is_a(hole, empty_space). @from 2026-11-16T19:23:32 @conf 1 @source teacher:pretrain
```
