# jupiter

```datalog
proper_name(jupiter). @from 2026-11-16T19:21:54 @conf 1 @source parser
is_a(jupiter, largest_planet). @from 2026-11-16T19:21:57 @conf 1 @source teacher:pretrain
is_a(jupiter, planet). @from 2026-11-16T20:01:18 @conf 1 @source teacher:pretrain
property(jupiter, quality, bright). @from 2026-11-16T20:23:18 @conf 1 @source teacher:chat
property(jupiter, size, biggest). @from 2026-11-16T20:26:03 @conf 1 @source teacher:chat
is_a(jupiter, gas_giant). @from 2026-11-16T20:26:19 @conf 1 @source teacher:chat
has(jupiter, red_spot). @from 2026-11-16T20:26:19 @conf 1 @source teacher:chat
property(jupiter, quality, bigger_than_earth). @from 2026-11-16T20:27:04 @conf 1 @source teacher:chat
has(jupiter, moon). @from 2026-11-16T20:27:21 @conf 1 @source teacher:chat
```
