# africa_where

```datalog
proper_name(africa_where). @from 2026-11-16T19:44:32 @conf 1 @source parser
```
