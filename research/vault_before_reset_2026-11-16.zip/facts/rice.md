# rice

```datalog
cook_in(rice, pot). @from 2026-11-16T20:29:48 @conf 1 @source teacher:chat
```
