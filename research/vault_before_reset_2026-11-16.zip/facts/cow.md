# cow

```datalog
is_a(cow, farm_animal). @from 2026-11-16T19:18:57 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:16
is_a(cow, animal). @from 2026-11-16T19:20:09 @conf 1 @source teacher:pretrain
```
