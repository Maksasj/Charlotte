# floating

```datalog
proper_name(floating). @from 2026-11-16T20:32:05 @conf 1 @source parser
```
