# jacket

```datalog
is_a(jacket, layer). @from 2026-11-16T20:08:10 @conf 1 @source teacher:pretrain
property(jacket, quality, waterproof). @from 2026-11-16T20:55:24 @until 2026-11-16T20:56:38 @conf 1 @source teacher:train
```
