# italy

```datalog
proper_name(italy). @from 2026-11-16T19:15:42 @conf 1 @source parser
is_a(italy, country_in_europe). @from 2026-11-16T19:20:36 @conf 1 @source teacher:pretrain
property(italy, capital, rome). @from 2026-11-16T19:50:18 @conf 1 @source teacher:pretrain
```
