# door

```datalog
part_of(door, house). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
```
