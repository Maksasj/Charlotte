# goalkeeper

```datalog
use(goalkeeper, hand). @from 2026-11-16T20:14:41 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:14:41
grab(goalkeeper, ball). @from 2026-11-16T20:24:47 @conf 1 @source teacher:chat
```
