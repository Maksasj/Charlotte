# big_city

```datalog
located_in(big_city, many_country). @from 2026-11-16T19:21:12 @until 2026-11-16T19:21:18 @conf 1 @source teacher:pretrain
located_in(big_city, country). @from 2026-11-16T19:21:18 @conf 1 @source teacher:pretrain
has(big_city, many_people). @from 2026-11-16T19:22:04 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:22:11
is_a(big_city, place). @from 2026-11-16T19:55:30 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:00:17
```
