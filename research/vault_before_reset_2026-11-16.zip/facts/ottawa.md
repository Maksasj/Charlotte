# ottawa

```datalog
proper_name(ottawa). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(ottawa, canada). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
```
