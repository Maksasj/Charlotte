# aphid

```datalog
is_a(aphid, bug). @from 2026-11-16T20:29:42 @conf 1 @source teacher:chat
property(aphid, size, tiny). @from 2026-11-16T20:29:42 @conf 1 @source teacher:chat
located_in(aphid, plant). @from 2026-11-16T20:29:42 @conf 1 @source teacher:chat
property(aphid, quality, soft_bodied). @from 2026-11-16T20:30:03 @conf 1 @source teacher:chat
sit_on(aphid, plant). @from 2026-11-16T20:30:03 @conf 1 @source teacher:chat
suck_out(aphid, sap). @from 2026-11-16T20:30:03 @conf 1 @source teacher:chat
leave_behind(aphid, liquid). @from 2026-11-16T20:30:03 @conf 1 @source teacher:chat
```
