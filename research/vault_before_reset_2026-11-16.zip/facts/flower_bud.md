# flower_bud

```datalog
part_of(flower_bud, broccoli). @from 2026-11-16T19:54:36 @conf 1 @source teacher:pretrain
```
