# old_city

```datalog
has(old_city, narrow_street). @from 2026-11-16T20:28:42 @conf 1 @source teacher:chat
```
