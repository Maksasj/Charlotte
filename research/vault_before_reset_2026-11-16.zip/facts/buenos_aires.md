# buenos_aires

```datalog
proper_name(buenos_aires). @from 2026-11-16T20:00:02 @conf 1 @source parser
is_a(buenos_aires, city). @from 2026-11-16T20:00:44 @conf 1 @source teacher:pretrain
property(buenos_aires, role, capital_of_argentina). @from 2026-11-16T20:02:05 @conf 1 @source teacher:pretrain
```
