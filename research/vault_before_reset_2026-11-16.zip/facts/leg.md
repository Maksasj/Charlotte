# leg

```datalog
part_of(leg, thorax). @from 2026-11-16T19:42:08 @conf 1 @source teacher:pretrain
hold(leg, seat). @from 2026-11-16T20:05:36 @conf 1 @source teacher:pretrain
-hold(leg, floor). @from 2026-11-16T20:05:36 @conf 1 @source teacher:pretrain
part_of(leg, chair). @from 2026-11-16T20:09:19 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T20:10:32
hold_up(leg, seat). @from 2026-11-16T20:11:11 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:11:11
power(leg, bicycle). @from 2026-11-16T20:13:47 @conf 1 @source teacher:pretrain
```
