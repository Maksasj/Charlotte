# basil_plant

```datalog
located_in(basil_plant, kitchen_counter). @from 2026-11-16T20:27:01 @conf 1 @source teacher:chat
```
