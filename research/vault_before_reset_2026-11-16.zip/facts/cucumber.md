# cucumber

```datalog
grow_on(cucumber, vine). @from 2026-11-16T19:49:31 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:52:49
```
