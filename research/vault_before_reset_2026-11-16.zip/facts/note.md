# note

```datalog
part_of(note, song). @from 2026-11-16T20:25:11 @conf 1 @source teacher:chat
```
