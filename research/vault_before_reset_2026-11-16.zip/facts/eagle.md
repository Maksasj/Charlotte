# eagle

```datalog
is_a(eagle, bird). @from 2026-11-16T19:19:40 @conf 1 @source teacher:pretrain @uses 4 @last 2026-11-16T19:26:09
```
