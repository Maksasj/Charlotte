# offside_rule

```datalog
property(offside_rule, quality, confusing). @from 2026-11-16T20:27:19 @conf 1 @source teacher:chat
is_a(offside_rule, rule). @from 2026-11-16T20:27:45 @conf 1 @source teacher:chat
```
