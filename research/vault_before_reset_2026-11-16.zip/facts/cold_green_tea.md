# cold_green_tea

```datalog
property(cold_green_tea, quality, great). @from 2026-11-16T20:29:06 @conf 1 @source teacher:chat
```
