# frost

```datalog
property(frost, cause, cold_nights). @from 2026-11-16T20:28:18 @conf 1 @source teacher:chat
```
