# good_your_brake

```datalog
part_of(good_your_brake, car). @from 2026-11-16T19:23:37 @conf 1 @source teacher:pretrain
```
