# amazon

```datalog
proper_name(amazon). @from 2026-11-16T19:17:02 @conf 1 @source parser
located_in(amazon, south_america). @from 2026-11-16T19:17:02 @conf 1 @source teacher:pretrain
```
