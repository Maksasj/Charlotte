# nurse

```datalog
property(nurse, quality, caring). @from 2026-11-16T19:16:21 @conf 1 @source teacher:pretrain
part_of(nurse, hospital_team). @from 2026-11-16T19:16:21 @conf 1 @source teacher:pretrain
help(nurse, sick_student). @from 2026-11-16T19:24:08 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:24:40
is_a(nurse, health_worker). @from 2026-11-16T19:24:11 @conf 1 @source teacher:pretrain
is_a(nurse, person). @from 2026-11-16T20:12:06 @conf 1 @source teacher:pretrain
look_after(nurse, patient). @from 2026-11-16T20:12:06 @conf 1 @source teacher:pretrain
give(nurse, medicine). @from 2026-11-16T20:12:06 @conf 1 @source teacher:pretrain
check_on(nurse, patient). @from 2026-11-16T20:12:06 @conf 1 @source teacher:pretrain
check(nurse, vital_sign). @from 2026-11-16T20:14:50 @conf 1 @source teacher:pretrain
track(nurse, chart). @from 2026-11-16T20:16:27 @conf 1 @source teacher:pretrain
look_after(nurse, kid). @from 2026-11-16T20:17:20 @conf 1 @source teacher:pretrain
help(nurse, kid). @from 2026-11-16T20:18:04 @conf 1 @source teacher:pretrain
keep_track_of(nurse, vital_sign). @from 2026-11-16T20:18:47 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:19:41
clean(nurse, knee). @from 2026-11-16T20:19:48 @conf 1 @source teacher:pretrain
put_on(nurse, bandage). @from 2026-11-16T20:19:48 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:19:48
property(nurse, job, lot_of_small_checks). @from 2026-11-16T20:28:32 @conf 1 @source teacher:chat
property(nurse, quality, useful). @from 2026-11-16T20:28:43 @conf 1 @source teacher:chat
```
