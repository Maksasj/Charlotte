# no_lion

```datalog
live_on(no_lion, land). @from 2026-11-16T19:19:34 @until 2026-11-16T19:19:57 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:19:40
```
