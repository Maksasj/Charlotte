# beak

```datalog
part_of(beak, bird). @from 2026-11-16T19:44:47 @conf 1 @source teacher:pretrain
make_of(beak, keratin). @from 2026-11-16T19:44:47 @conf 1 @source teacher:pretrain
```
