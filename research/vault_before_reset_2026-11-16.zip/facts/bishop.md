# bishop

```datalog
move(bishop, diagonal). @from 2026-11-16T20:26:13 @conf 1 @source teacher:chat
property(bishop, value, close_to_rook). @from 2026-11-16T20:27:30 @until 2026-11-16T20:27:46 @conf 1 @source teacher:chat
go(bishop, diagonal). @from 2026-11-16T20:27:30 @conf 1 @source teacher:chat
```
