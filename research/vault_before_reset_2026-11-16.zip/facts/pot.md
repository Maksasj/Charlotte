# pot

```datalog
is_a(pot, container). @from 2026-11-16T19:52:59 @conf 1 @source teacher:pretrain
is_a(pot, deep_container). @from 2026-11-16T19:54:42 @conf 1 @source teacher:pretrain
property(pot, quality, heavy). @from 2026-11-16T20:29:48 @conf 1 @source teacher:chat
```
