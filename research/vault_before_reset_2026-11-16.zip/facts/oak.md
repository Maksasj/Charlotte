# oak

```datalog
property(oak, size, big). @from 2026-11-16T19:17:02 @conf 1 @source teacher:pretrain
```
