# lakes

```datalog
proper_name(lakes). @from 2026-11-16T20:30 @conf 1 @source parser
```
