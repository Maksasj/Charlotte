# beijing

```datalog
proper_name(beijing). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(beijing, china). @from 2026-11-16T19:15:42 @until 2026-11-16T19:53:15 @conf 1 @source teacher:pretrain
is_a(beijing, capital_of_china). @from 2026-11-16T19:21:05 @conf 1 @source teacher:pretrain
located_in(beijing, north_china). @from 2026-11-16T19:53:15 @until 2026-11-16T19:54:09 @conf 1 @source teacher:pretrain
located_in(beijing, china). @from 2026-11-16T19:54:09 @until 2026-11-16T19:55:19 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:54:57
located_in(beijing, north_china). @from 2026-11-16T19:55:19 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:55:19
```
