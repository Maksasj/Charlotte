# japan

```datalog
proper_name(japan). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(japan, asia). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
is_a(japan, country_in_asia). @from 2026-11-16T19:20:14 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:49:10
is_a(japan, country). @from 2026-11-16T19:20:54 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:49:10
make_of(japan, island). @from 2026-11-16T19:48:27 @until 2026-11-16T19:56:20 @conf 1 @source teacher:pretrain
property(japan, capital, tokyo). @from 2026-11-16T19:49:10 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:59:42
has(japan, island). @from 2026-11-16T19:50:03 @conf 1 @source teacher:pretrain
```
