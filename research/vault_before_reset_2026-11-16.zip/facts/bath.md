# bath

```datalog
located_in(bath, bathroom). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
property(bath, size, big). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
```
