# kid

```datalog
learn(kid, math). @from 2026-11-16T20:14:12 @conf 1 @source teacher:pretrain
learn(kid, reading). @from 2026-11-16T20:14:12 @conf 1 @source teacher:pretrain
learn(kid, science). @from 2026-11-16T20:14:12 @conf 1 @source teacher:pretrain
```
