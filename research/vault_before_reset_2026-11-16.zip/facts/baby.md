# baby

```datalog
property(baby, size, small). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
```
