# apple

```datalog
is_a(apple, fruit). @from 2026-11-16T19:15:24 @conf 1 @source teacher:pretrain @uses 4 @last 2026-11-16T19:38:06
has(apple, seed). @from 2026-11-16T19:15:24 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:38:06
property(apple, quality, fruit). @from 2026-11-16T19:18:43 @until 2026-11-16T19:19:07 @conf 1 @source teacher:pretrain
property(apple, quality, sweet). @from 2026-11-16T19:19:07 @until 2026-11-16T19:39:06 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:38:06
property(apple, colour, red). @from 2026-11-16T19:25:28 @until 2026-11-16T19:37:24 @conf 1 @source teacher:pretrain
-is_a(apple, plant). @from 2026-11-16T19:25:40 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:38:06
property(apple, colour, green). @from 2026-11-16T19:37:24 @until 2026-11-16T19:37:24 @conf 1 @source teacher:pretrain
property(apple, colour, yellow). @from 2026-11-16T19:37:24 @until 2026-11-16T19:38:06 @conf 1 @source teacher:pretrain
property(apple, colour, green). @from 2026-11-16T19:38:06 @until 2026-11-16T19:38:06 @conf 1 @source teacher:pretrain
property(apple, colour, red). @from 2026-11-16T19:38:06 @until 2026-11-16T19:38:06 @conf 1 @source teacher:pretrain
property(apple, colour, yellow). @from 2026-11-16T19:38:06 @until 2026-11-16T19:39:06 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:38:06
property(apple, colour, red). @from 2026-11-16T19:39:06 @until 2026-11-16T19:39:06 @conf 1 @source teacher:pretrain
property(apple, colour, green). @from 2026-11-16T19:39:06 @until 2026-11-16T20:29:04 @conf 1 @source teacher:pretrain
property(apple, quality, tart). @from 2026-11-16T19:39:06 @conf 1 @source teacher:pretrain
grow_on(apple, tree). @from 2026-11-16T19:41:10 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T20:29
property(apple, best_picked_time, autumn). @from 2026-11-16T20:28:13 @conf 1 @source teacher:chat
grow_on(apple, apple_tree). @from 2026-11-16T20:28:46 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:29
property(apple, colour, red). @from 2026-11-16T20:29:04 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:30:42
grow_on(apple, branch). @from 2026-11-16T20:29:15 @conf 1 @source teacher:chat
-grow_on(apple, trunk). @from 2026-11-16T20:29:15 @conf 1 @source teacher:chat
hang_from(apple, branch). @from 2026-11-16T20:29:58 @conf 1 @source teacher:chat
has(apple, branch). @from 2026-11-16T20:30:14 @conf 1 @source teacher:chat
```
