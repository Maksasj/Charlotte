# half

```datalog
part_of(half, match). @from 2026-11-16T20:17:50 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:17:50
```
