# low_temperature

```datalog
property(low_temperature, time, overnight_or_early_morning). @from 2026-11-16T20:58:50 @conf 1 @source teacher:train
property(low_temperature, quality, coldest_of_day). @from 2026-11-16T20:58:50 @conf 1 @source teacher:train
```
