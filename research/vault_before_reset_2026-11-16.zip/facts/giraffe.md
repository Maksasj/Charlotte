# giraffe

```datalog
property(giraffe, tongue, long). @from 2026-11-16T20:24:34 @conf 1 @source teacher:chat
property(giraffe, size, tall). @from 2026-11-16T20:25:05 @conf 1 @source teacher:chat
reach(giraffe, leaf). @from 2026-11-16T20:25:05 @conf 1 @source teacher:chat
eat(giraffe, leaf). @from 2026-11-16T20:25:25 @conf 1 @source teacher:chat
eat_from(giraffe, acacia_tree). @from 2026-11-16T20:25:25 @conf 1 @source teacher:chat
use(giraffe, tongue). @from 2026-11-16T20:25:25 @conf 1 @source teacher:chat
pull(giraffe, leaf). @from 2026-11-16T20:25:25 @conf 1 @source teacher:chat
proper_name(giraffe). @from 2026-11-16T20:25:56 @conf 1 @source parser
has(giraffe, long_neck). @from 2026-11-16T20:26:27 @conf 1 @source teacher:chat
```
