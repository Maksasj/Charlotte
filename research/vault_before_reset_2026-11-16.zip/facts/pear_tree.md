# pear_tree

```datalog
located_in(pear_tree, my_yard). @until 2026-11-16T20:23:44 @conf 1 @source teacher:chat
```
