# roof

```datalog
part_of(roof, house). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
```
