# insect

```datalog
has(insect, six_leg). @from 2026-11-16T19:18:34 @conf 1 @source teacher:pretrain @uses 4 @last 2026-11-16T19:40:52
is_a(insect, animal). @from 2026-11-16T19:18:48 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T19:37:46
has(insect, antenna). @from 2026-11-16T19:19:04 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T19:40:52
has(insect, three_body_part). @from 2026-11-16T19:19:11 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T19:40:52
property(insect, size, large). @from 2026-11-16T19:37:08 @until 2026-11-16T19:46:04 @conf 1 @source teacher:pretrain
has(insect, body_part). @from 2026-11-16T19:38:38 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:40:52
has(insect, leg). @from 2026-11-16T19:38:38 @conf 1 @source teacher:pretrain @uses 3 @last 2026-11-16T19:40:52
-has(insect, blood). @from 2026-11-16T19:38:38 @conf 1 @source teacher:pretrain
```
