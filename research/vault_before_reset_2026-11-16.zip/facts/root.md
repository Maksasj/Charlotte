# root

```datalog
part_of(root, plant). @from 2026-11-16T19:17:02 @conf 1 @source teacher:pretrain
```
