# brazil

```datalog
proper_name(brazil). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(brazil, south_america). @from 2026-11-16T19:15:42 @conf 1 @source teacher:pretrain
-located_in(brazil, africa). @from 2026-11-16T19:21:12 @conf 1 @source teacher:pretrain
is_a(brazil, country). @from 2026-11-16T19:21:12 @conf 1 @source teacher:pretrain
property(brazil, size, big). @from 2026-11-16T19:55:48 @until 2026-11-16T19:56:20 @conf 1 @source teacher:pretrain
is_a(brazil, biggest_country_in_south_america). @from 2026-11-16T19:55:48 @conf 1 @source teacher:pretrain
is_a(brazil, biggest_country). @from 2026-11-16T19:56:20 @conf 1 @source teacher:pretrain
property(brazil, size, biggest). @from 2026-11-16T19:56:20 @until 2026-11-16T20:03:07 @conf 1 @source teacher:pretrain
-is_a(brazil, south_america_other). @from 2026-11-16T19:56:20 @until 2026-11-16T20:03:07 @conf 1 @source teacher:pretrain
speak(brazil, portuguese). @from 2026-11-16T19:56:20 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:56:20
property(brazil, capital, brasilia). @from 2026-11-16T19:56:53 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T20:02:57
```
