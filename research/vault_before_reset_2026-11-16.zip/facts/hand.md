# hand

```datalog
part_of(hand, human_body). @from 2026-11-16T19:17:23 @conf 1 @source teacher:pretrain
```
