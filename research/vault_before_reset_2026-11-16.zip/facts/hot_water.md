# hot_water

```datalog
pour_over(hot_water, tea_bag). @from 2026-11-16T20:56:44 @conf 1 @source teacher:train
```
