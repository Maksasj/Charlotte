# have

```datalog
proper_name(have). @from 2026-11-16T19:36:53 @conf 1 @source parser
```
