# now

```datalog
proper_name(now). @from 2026-11-16T20:56:24 @conf 1 @source parser
```
