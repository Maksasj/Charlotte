# outside

```datalog
property(outside, quality, blurry). @from 2026-11-16T20:26:34 @until 2026-11-16T20:27:49 @conf 1 @source teacher:chat
property(outside, quality, slow). @from 2026-11-16T20:26:34 @until 2026-11-16T20:27:49 @conf 1 @source teacher:chat
```
