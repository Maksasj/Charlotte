# mars

```datalog
proper_name(mars). @from 2026-11-16T19:21:41 @conf 1 @source parser
is_a(mars, planet). @from 2026-11-16T19:21:41 @conf 1 @source teacher:pretrain
is_a(mars, fourth_planet_from_sun). @from 2026-11-16T19:21:45 @conf 1 @source teacher:pretrain
is_a(mars, fourth_planet). @from 2026-11-16T19:21:48 @conf 1 @source teacher:pretrain
```
