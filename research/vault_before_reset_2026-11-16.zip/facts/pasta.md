# pasta

```datalog
cook_in(pasta, pot). @from 2026-11-16T20:29:48 @conf 1 @source teacher:chat
proper_name(pasta). @from 2026-11-16T20:30:42 @conf 1 @source parser
```
