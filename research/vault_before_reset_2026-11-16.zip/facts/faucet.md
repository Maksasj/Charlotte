# faucet

```datalog
located_in(faucet, kitchen). @from 2026-11-16T20:28:01 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:28:48
```
