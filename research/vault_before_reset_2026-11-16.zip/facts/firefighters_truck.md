# firefighters_truck

```datalog
property(firefighters_truck, colour, red). @from 2026-11-16T19:16:21 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:30:42
```
