# boat

```datalog
is_a(boat, vehicle). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain
```
