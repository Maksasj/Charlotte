# pansy

```datalog
wants(pansy, sun). @from 2026-11-16T21:08:26 @conf 1 @source teacher:train
grow_in(pansy, pot). @from 2026-11-16T21:08:26 @conf 1 @source teacher:train
flower(pansy). @from 2026-11-16T21:08:26 @conf 1 @source teacher:train
```
