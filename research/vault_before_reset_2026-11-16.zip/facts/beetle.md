# beetle

```datalog
located_in(beetle, leaf). @from 2026-11-16T20:25:08 @conf 1 @source teacher:chat
property(beetle, size, tiny). @from 2026-11-16T20:28:29 @conf 1 @source teacher:chat
property(beetle, quality, hard_shell). @from 2026-11-16T20:28:48 @conf 1 @source teacher:chat
property(beetle, quality, shiny). @from 2026-11-16T20:28:48 @conf 1 @source teacher:chat
```
