# chain

```datalog
spin(chain, back_wheel). @from 2026-11-16T20:13:08 @conf 1 @source teacher:pretrain
connect(chain, gear). @from 2026-11-16T20:15:25 @until 2026-11-16T20:17:40 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:16:57
loop_around(chain, chainring). @from 2026-11-16T20:17:40 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:17:40
loop_around(chain, cog). @from 2026-11-16T20:17:40 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:17:40
-connect(chain, gear). @from 2026-11-16T20:17:40 @conf 1 @source teacher:pretrain
loop_around(chain, small_gear). @from 2026-11-16T20:19:22 @conf 1 @source teacher:pretrain
```
