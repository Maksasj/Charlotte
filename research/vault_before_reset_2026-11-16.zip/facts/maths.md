# maths

```datalog
proper_name(maths). @from 2026-11-16T19:25:05 @conf 1 @source parser
is_a(maths, school_subject). @from 2026-11-16T19:25:05 @conf 1 @source teacher:pretrain
```
