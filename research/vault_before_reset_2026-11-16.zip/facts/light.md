# light

```datalog
split(light, color). @from 2026-11-16T20:27:16 @conf 1 @source teacher:chat
change(light). @from 2026-11-16T20:28:55 @conf 1 @source teacher:chat
```
