# guitar

```datalog
is_a(guitar, instrument). @from 2026-11-16T19:24:39 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:26:16
is_a(guitar, string_instrument). @from 2026-11-16T19:25:07 @conf 1 @source teacher:pretrain
```
