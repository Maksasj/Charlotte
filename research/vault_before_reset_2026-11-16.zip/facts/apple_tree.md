# apple_tree

```datalog
is_a(apple_tree, tree). @from 2026-11-16T19:41:10 @conf 1 @source teacher:pretrain
located_in(apple_tree, apple_orchard). @from 2026-11-16T20:25:54 @until 2026-11-16T20:29:04 @conf 1 @source teacher:chat
property(apple_tree, quality, turning). @from 2026-11-16T20:28:29 @conf 1 @source teacher:chat
is_a(apple_tree, plant). @from 2026-11-16T20:28:46 @conf 1 @source teacher:chat
part_of(apple_tree, plant). @from 2026-11-16T20:28:46 @conf 1 @source teacher:chat
located_in(apple_tree, path). @from 2026-11-16T20:29:04 @conf 1 @source teacher:chat
has(apple_tree, flower). @from 2026-11-16T20:29:04 @conf 1 @source teacher:chat
```
