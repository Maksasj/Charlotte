# petal

```datalog
drift_down(petal). @from 2026-11-16T20:28:44 @conf 1 @source teacher:chat
```
