# referee

```datalog
check(referee, pressure). @from 2026-11-16T20:26:48 @until 2026-11-16T20:28:17 @conf 1 @source teacher:chat
is_a(referee, person). @from 2026-11-16T20:27:06 @conf 1 @source teacher:chat
blow(referee, whistle). @from 2026-11-16T20:27:06 @conf 1 @source teacher:chat
```
