# hemolymph

```datalog
is_a(hemolymph, fluid). @from 2026-11-16T19:38:38 @conf 1 @source teacher:pretrain
proper_name(hemolymph). @from 2026-11-16T19:39:21 @conf 1 @source parser
-is_a(hemolymph, blood). @from 2026-11-16T19:39:28 @conf 1 @source teacher:pretrain
```
