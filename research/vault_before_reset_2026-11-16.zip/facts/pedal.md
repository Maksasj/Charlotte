# pedal

```datalog
turn(pedal, chain). @from 2026-11-16T20:13:08 @conf 1 @source teacher:pretrain
```
