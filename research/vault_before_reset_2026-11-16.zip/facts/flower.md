# flower

```datalog
has(flower, petal). @from 2026-11-16T19:17:02 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:26:40
part_of(flower, plant). @from 2026-11-16T19:25:38 @conf 1 @source teacher:pretrain
is_a(flower, plant). @from 2026-11-16T19:26:16 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:26:40
property(flower, colour, white). @from 2026-11-16T20:29:04 @until 2026-11-16T20:29:04 @conf 1 @source teacher:chat
property(flower, colour, pink). @from 2026-11-16T20:29:04 @conf 1 @source teacher:chat
```
