# dining_chair

```datalog
is_a(dining_chair, chair). @from 2026-11-16T20:07:40 @conf 1 @source teacher:pretrain
```
