# big_gear

```datalog
is_a(big_gear, chainring). @from 2026-11-16T20:16:11 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:16:11
```
