# back_leg

```datalog
property(back_leg, quality, strong). @from 2026-11-16T20:25:54 @conf 1 @source teacher:chat
```
