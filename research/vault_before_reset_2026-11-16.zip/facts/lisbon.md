# lisbon

```datalog
proper_name(lisbon). @from 2026-11-16T19:53:22 @conf 1 @source parser
located_in(lisbon, coast). @from 2026-11-16T19:53:29 @conf 1 @source teacher:pretrain
```
