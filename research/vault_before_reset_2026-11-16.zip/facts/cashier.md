# cashier

```datalog
work_in(cashier, shop). @from 2026-11-16T19:24:10 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:25:14
take(cashier, money_from_customer). @from 2026-11-16T19:24:10 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:14:17
take(cashier, money). @from 2026-11-16T19:24:26 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T20:15:56
is_a(cashier, person). @from 2026-11-16T20:13:32 @conf 1 @source teacher:pretrain
work_at(cashier, register). @from 2026-11-16T20:13:32 @conf 1 @source teacher:pretrain
works_at(cashier, register). @from 2026-11-16T20:14:16 @conf 1 @source teacher:pretrain
is_a(cashier, cashier). @from 2026-11-16T20:14:16 @conf 1 @source teacher:pretrain
is_a(cashier, cashier_role). @from 2026-11-16T20:14:17 @conf 1 @source teacher:pretrain
give_back(cashier, change). @from 2026-11-16T20:17:27 @conf 1 @source teacher:pretrain
```
