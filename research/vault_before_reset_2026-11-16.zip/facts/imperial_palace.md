# imperial_palace

```datalog
proper_name(imperial_palace). @from 2026-11-16T20:00:09 @conf 1 @source parser
located_in(imperial_palace, tokyo). @from 2026-11-16T20:01 @conf 1 @source teacher:pretrain
```
