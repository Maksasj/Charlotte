# nigeria

```datalog
proper_name(nigeria). @from 2026-11-16T19:20:53 @conf 1 @source parser
located_in(nigeria, africa). @from 2026-11-16T19:20:53 @conf 1 @source teacher:pretrain
is_a(nigeria, country). @from 2026-11-16T19:21:36 @conf 1 @source teacher:pretrain
```
