# phone

```datalog
has(phone, screen). @from 2026-11-16T19:25:22 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:26:17
is_a(phone, machine). @from 2026-11-16T19:25:32 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:25:54
is_a(phone, computer). @from 2026-11-16T19:25:35 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:25:54
has(phone, battery). @from 2026-11-16T19:25:47 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:25:54
has(phone, camera). @from 2026-11-16T19:25:54 @until 2026-11-16T19:26:03 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:25:54
-has(phone, camera). @from 2026-11-16T19:26:03 @until 2026-11-16T19:26:10 @conf 1 @source teacher:pretrain
has(phone, no_physical_keyboard). @from 2026-11-16T19:26:03 @conf 1 @source teacher:pretrain
has(phone, camera). @from 2026-11-16T19:26:10 @conf 1 @source teacher:pretrain
```
