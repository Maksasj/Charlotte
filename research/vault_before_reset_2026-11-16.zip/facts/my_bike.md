# my_bike

```datalog
has(my_bike, flat_tire). @from 2026-11-16T21:08:40 @until 2026-11-16T21:10:24 @conf 1 @source teacher:train
```
