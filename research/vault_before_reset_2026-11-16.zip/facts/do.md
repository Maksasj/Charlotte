# do

```datalog
proper_name(do). @from 2026-11-16T19:42:38 @conf 1 @source parser
```
