# no_hat

```datalog
-cover(no_hat, your_feet). @from 2026-11-16T19:23:23 @until 2026-11-16T19:24:15 @conf 1 @source teacher:pretrain
```
