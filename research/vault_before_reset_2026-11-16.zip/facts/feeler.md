# feeler

```datalog
is_a(feeler, antenna). @from 2026-11-16T19:45:21 @until 2026-11-16T19:46:04 @conf 1 @source teacher:pretrain
```
