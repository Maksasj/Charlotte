# portuguese

```datalog
proper_name(portuguese). @from 2026-11-16T19:55:44 @conf 1 @source parser
```
