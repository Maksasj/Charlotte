# food

```datalog
proper_name(food). @from 2026-11-16T20:56:35 @conf 1 @source parser
```
