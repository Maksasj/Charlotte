# organ

```datalog
is_a(organ, body_part). @from 2026-11-16T19:26:55 @conf 1 @source teacher:pretrain
```
