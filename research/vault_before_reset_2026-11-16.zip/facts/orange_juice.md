# orange_juice

```datalog
is_a(orange_juice, breakfast_drink). @from 2026-11-16T19:20:29 @conf 1 @source teacher:pretrain
```
