# knife

```datalog
property(knife, plural, knives). @from 2026-11-16T19:20:18 @conf 1 @source teacher:pretrain
cut(knife, food). @from 2026-11-16T19:20:36 @conf 1 @source teacher:pretrain
```
