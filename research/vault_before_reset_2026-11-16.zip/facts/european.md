# european

```datalog
proper_name(european). @from 2026-11-16T20:28:27 @conf 1 @source parser
```
