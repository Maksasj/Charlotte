# picnic_list

```datalog
cover(picnic_list, food). @from 2026-11-16T20:55:24 @conf 1 @source teacher:train
cover(picnic_list, drink). @from 2026-11-16T20:55:24 @conf 1 @source teacher:train
cover(picnic_list, gear). @from 2026-11-16T20:55:24 @conf 1 @source teacher:train
name(picnic_list, item). @from 2026-11-16T20:56:26 @conf 1 @source teacher:train
```
