# hammer

```datalog
is_a(hammer, tool). @from 2026-11-16T19:15:59 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:03:38
has(hammer, handle). @from 2026-11-16T19:15:59 @conf 1 @source teacher:pretrain
hit(hammer, nail). @from 2026-11-16T19:23:19 @conf 1 @source teacher:pretrain
pull(hammer, nail). @from 2026-11-16T20:04:45 @conf 1 @source teacher:pretrain
-wants(hammer, power). @from 2026-11-16T20:06:01 @conf 1 @source teacher:pretrain
```
