# bagel

```datalog
is_a(bagel, bread). @from 2026-11-16T19:53:22 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:53:22
property(bagel, quality, round). @from 2026-11-16T19:53:22 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:05:48
has(bagel, hole). @from 2026-11-16T19:53:22 @conf 1 @source teacher:pretrain
property(bagel, shape, round). @from 2026-11-16T19:54:19 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:54:19
```
