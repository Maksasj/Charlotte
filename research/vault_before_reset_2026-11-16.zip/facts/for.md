# for

```datalog
proper_name(for). @from 2026-11-16T20:55:56 @conf 1 @source parser
```
