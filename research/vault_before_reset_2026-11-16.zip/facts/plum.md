# plum

```datalog
property(plum, colour, purple). @from 2026-11-16T19:22:56 @conf 1 @source teacher:pretrain
```
