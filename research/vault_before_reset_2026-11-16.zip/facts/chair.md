# chair

```datalog
property(chair, quality, furniture). @from 2026-11-16T19:17:33 @until 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
has(chair, leg). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:04:59
part_of(chair, dining_set). @from 2026-11-16T19:17:33 @until 2026-11-16T19:17:44 @conf 1 @source teacher:pretrain
property(chair, quality, hard). @from 2026-11-16T19:17:33 @until 2026-11-16T19:22:48 @conf 1 @source teacher:pretrain
property(chair, quality, furniture). @from 2026-11-16T19:22:48 @conf 1 @source teacher:pretrain
property(chair, quantity, 4). @from 2026-11-16T20:05:36 @conf 1 @source teacher:pretrain
is_a(chair, furniture). @from 2026-11-16T20:06:16 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:09:49
has(chair, armrest). @from 2026-11-16T20:06:59 @conf 1 @source teacher:pretrain
```
