# put

```datalog
proper_name(put). @from 2026-11-16T20:58:31 @conf 1 @source parser
```
