# crust

```datalog
property(crust, quality, crunchy). @from 2026-11-16T20:27:02 @conf 1 @source teacher:chat
```
