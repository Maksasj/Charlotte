# hagelslag

```datalog
is_a(hagelslag, breakfast). @from 2026-11-16T20:25:49 @until 2026-11-16T20:28:26 @conf 1 @source teacher:chat
proper_name(hagelslag). @from 2026-11-16T20:26:09 @conf 1 @source parser
property(hagelslag, quality, popular). @from 2026-11-16T20:26:25 @conf 1 @source teacher:chat
```
