# japan_government

```datalog
meet_in(japan_government, national_diet_building). @from 2026-11-16T20:01:42 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:01:42
```
