# cup

```datalog
is_a(cup, container). @from 2026-11-16T19:15:59 @conf 1 @source teacher:pretrain
has(cup, handle). @from 2026-11-16T19:15:59 @conf 1 @source teacher:pretrain
```
