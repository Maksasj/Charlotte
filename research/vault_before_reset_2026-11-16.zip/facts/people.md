# people

```datalog
drink(people, water). @from 2026-11-16T19:15:25 @conf 1 @source teacher:pretrain
located_in(people, city). @from 2026-11-16T19:15:42 @until 2026-11-16T19:15:50 @conf 1 @source teacher:pretrain
sleep_in(people, bed). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
cook_in(people, kitchen). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
wash_in(people, bathroom). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
sit_on(people, chair). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
eat(people, breakfast_in_morning). @from 2026-11-16T19:20:17 @conf 1 @source teacher:pretrain
use(people, tools_to_work). @from 2026-11-16T19:22:48 @until 2026-11-16T19:23:01 @conf 1 @source teacher:pretrain
-use(people, tools_to_work). @from 2026-11-16T19:23:01 @until 2026-11-16T19:23:39 @conf 1 @source teacher:pretrain
use(people, tool). @from 2026-11-16T19:23:01 @conf 1 @source teacher:pretrain
sleep_on(people, bed). @from 2026-11-16T19:23:08 @conf 1 @source teacher:pretrain
play(people, sports_with_their_body). @from 2026-11-16T19:24:23 @conf 1 @source teacher:pretrain
play(people, sport). @from 2026-11-16T19:24:36 @until 2026-11-16T19:25:33 @conf 1 @source teacher:pretrain
property(people, quality, sleepy). @from 2026-11-16T20:26:44 @until 2026-11-16T20:28:09 @conf 1 @source teacher:chat
eat(people, crusty_bread_roll). @from 2026-11-16T20:27:09 @conf 1 @source teacher:chat
located_in(people, germany). @from 2026-11-16T20:27:09 @until 2026-11-16T20:28:26 @conf 1 @source teacher:chat
grow(people, food). @from 2026-11-16T20:27:39 @conf 1 @source teacher:chat
grow(people, flower). @from 2026-11-16T20:27:39 @conf 1 @source teacher:chat @uses 1 @last 2026-11-16T20:29:04
likes(people, savory_breakfast). @from 2026-11-16T20:28:03 @conf 1 @source teacher:chat
wander(people). @from 2026-11-16T20:29:11 @conf 1 @source teacher:chat
```
