# government

```datalog
located_in(government, tokyo). @from 2026-11-16T19:59:42 @conf 1 @source teacher:pretrain
meet_in(government, tokyo). @from 2026-11-16T20:00:17 @conf 1 @source teacher:pretrain
```
