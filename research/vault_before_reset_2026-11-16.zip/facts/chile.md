# chile

```datalog
proper_name(chile). @from 2026-11-16T19:21:39 @conf 1 @source parser
located_in(chile, south_america). @from 2026-11-16T19:21:39 @conf 1 @source teacher:pretrain
speak(chile, spanish). @from 2026-11-16T19:57:34 @conf 1 @source teacher:pretrain
property(chile, capital, santiago). @from 2026-11-16T20:00:44 @conf 1 @source teacher:pretrain
```
