# car

```datalog
is_a(car, vehicle). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain
has(car, wheel). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:22:43
property(car, quality, fast). @from 2026-11-16T19:16:44 @conf 1 @source teacher:pretrain
has(car, engine). @from 2026-11-16T19:23:09 @conf 1 @source teacher:pretrain
has(car, door). @from 2026-11-16T19:23:43 @conf 1 @source teacher:pretrain
property(car, quality, unknown). @from 2026-11-16T20:20:59 @conf 1 @source teacher:chat
```
