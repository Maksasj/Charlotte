# drinking

```datalog
proper_name(drinking). @from 2026-11-16T20:57:23 @conf 1 @source parser
```
