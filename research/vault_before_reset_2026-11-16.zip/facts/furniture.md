# furniture

```datalog
proper_name(furniture). @from 2026-11-16T19:22:40 @conf 1 @source parser
```
