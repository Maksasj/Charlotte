# cooky

```datalog
-is_a(cooky, breakfast_food). @from 2026-11-16T19:20:56 @conf 1 @source teacher:pretrain
```
