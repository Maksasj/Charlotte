# muffin

```datalog
is_a(muffin, cupcake). @from 2026-11-16T20:25:20 @until 2026-11-16T20:26:21 @conf 1 @source teacher:chat
-sweet(muffin). @from 2026-11-16T20:25:20 @until 2026-11-16T20:27:56 @conf 1 @source teacher:chat
property(muffin, quality, soft). @from 2026-11-16T20:25:20 @conf 1 @source teacher:chat
property(muffin, quality, fluffy). @from 2026-11-16T20:25:20 @conf 1 @source teacher:chat
is_a(muffin, bread). @from 2026-11-16T20:25:20 @conf 1 @source teacher:chat
-is_a(muffin, bread_and_cupcake_mix). @from 2026-11-16T20:26:08 @conf 1 @source teacher:chat
is_a(muffin, quick_bread). @from 2026-11-16T20:26:08 @conf 1 @source teacher:chat
property(muffin, quality, sweet). @from 2026-11-16T20:26:08 @conf 1 @source teacher:chat
property(muffin, size, small). @from 2026-11-16T20:26:21 @conf 1 @source teacher:chat
-is_a(muffin, cupcake). @from 2026-11-16T20:26:21 @conf 1 @source teacher:chat
bake_in(muffin, cup). @from 2026-11-16T20:26:35 @conf 1 @source teacher:chat
```
