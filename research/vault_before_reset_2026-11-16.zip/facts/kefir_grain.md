# kefir_grain

```datalog
add_to(kefir_grain, milk). @from 2026-11-16T19:48:20 @conf 1 @source teacher:pretrain
is_a(kefir_grain, colony). @from 2026-11-16T19:48:20 @conf 1 @source teacher:pretrain
change(kefir_grain, milk). @from 2026-11-16T19:49:03 @conf 1 @source teacher:pretrain
make(kefir_grain, kefir). @from 2026-11-16T19:49:55 @conf 1 @source teacher:pretrain
causes(kefir_grain, kefir). @from 2026-11-16T19:50:45 @conf 1 @source teacher:pretrain
-is_a(kefir_grain, grain). @from 2026-11-16T19:53:07 @conf 1 @source teacher:pretrain
is_a(kefir_grain, cluster). @from 2026-11-16T19:53:07 @conf 1 @source teacher:pretrain
has(kefir_grain, bacteria). @from 2026-11-16T19:53:07 @conf 1 @source teacher:pretrain
has(kefir_grain, yeast). @from 2026-11-16T19:53:07 @conf 1 @source teacher:pretrain
has(kefir_grain, bacterium). @from 2026-11-16T19:54:50 @conf 1 @source teacher:pretrain
turn_into(kefir_grain, kefir). @from 2026-11-16T19:54:50 @until 2026-11-16T19:55:12 @conf 1 @source teacher:pretrain
```
