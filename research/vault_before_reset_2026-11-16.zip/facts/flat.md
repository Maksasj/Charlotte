# flat

```datalog
property(flat, size, small). @from 2026-11-16T20:58:25 @conf 1 @source teacher:train
```
