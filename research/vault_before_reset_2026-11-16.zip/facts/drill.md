# drill

```datalog
is_a(drill, tool). @from 2026-11-16T19:23:25 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:03:38
make(drill, hole). @from 2026-11-16T19:23:32 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:26:09
wants(drill, power). @from 2026-11-16T20:06:01 @conf 1 @source teacher:pretrain
```
