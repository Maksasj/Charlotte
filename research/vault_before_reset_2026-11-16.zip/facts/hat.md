# hat

```datalog
is_a(hat, clothe). @from 2026-11-16T19:23:02 @conf 1 @source teacher:pretrain @uses 4 @last 2026-11-16T20:10:15
cover(hat, your_head). @from 2026-11-16T19:23:14 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:23:59
proper_name(hat). @from 2026-11-16T20:10:42 @conf 1 @source parser
go_on(hat, head). @from 2026-11-16T20:10:50 @conf 1 @source teacher:pretrain
is_a(hat, clothing). @from 2026-11-16T20:10:50 @conf 1 @source teacher:pretrain
```
