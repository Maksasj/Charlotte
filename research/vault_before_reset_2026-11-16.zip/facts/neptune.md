# neptune

```datalog
proper_name(neptune). @from 2026-11-16T20:00:29 @conf 1 @source parser
is_a(neptune, planet). @from 2026-11-16T20:01:18 @conf 1 @source teacher:pretrain
```
