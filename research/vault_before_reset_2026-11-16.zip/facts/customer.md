# customer

```datalog
pay_for(customer, food). @from 2026-11-16T19:24:53 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:25
```
