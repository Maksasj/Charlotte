# coast

```datalog
is_a(coast, edge). @from 2026-11-16T19:54:29 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:54:29
is_a(coast, place_where_land_meets_sea). @from 2026-11-16T19:55:12 @conf 1 @source teacher:pretrain
```
