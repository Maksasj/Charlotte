# mid_november

```datalog
property(mid_november, quality, cooling_stretch). @from 2026-11-16T20:57:21 @conf 1 @source teacher:train
```
