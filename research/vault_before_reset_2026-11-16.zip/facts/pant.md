# pant

```datalog
is_a(pant, clothe). @from 2026-11-16T19:22:53 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T19:23:59
go_on(pant, leg). @from 2026-11-16T20:07:22 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:08:10
```
