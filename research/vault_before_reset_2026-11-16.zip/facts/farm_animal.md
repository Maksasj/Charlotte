# farm_animal

```datalog
live_on(farm_animal, farm). @from 2026-11-16T19:19:11 @conf 1 @source teacher:pretrain
give(farm_animal, milk_egg). @from 2026-11-16T19:19:26 @until 2026-11-16T19:19:55 @conf 1 @source teacher:pretrain
give(farm_animal, wool). @from 2026-11-16T19:19:26 @until 2026-11-16T19:19:55 @conf 1 @source teacher:pretrain
```
