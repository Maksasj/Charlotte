# frost_on_car

```datalog
causes(frost_on_car, nights_dropping). @from 2026-11-16T20:28:18 @conf 1 @source teacher:chat
```
