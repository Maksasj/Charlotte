# fridge

```datalog
property(fridge, size, big). @from 2026-11-16T19:15:59 @conf 1 @source teacher:pretrain
has(fridge, door). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
property(fridge, quality, cold). @from 2026-11-16T19:17:33 @conf 1 @source teacher:pretrain
keep(fridge, food_cold). @from 2026-11-16T19:20:18 @conf 1 @source teacher:pretrain
proper_name(fridge). @from 2026-11-16T19:20:25 @conf 1 @source parser
keep(fridge, food). @from 2026-11-16T19:46:55 @conf 1 @source teacher:pretrain
keep(fridge, drink). @from 2026-11-16T19:46:55 @conf 1 @source teacher:pretrain
property(fridge, job, keep_cold). @from 2026-11-16T19:48:10 @conf 1 @source teacher:pretrain
```
