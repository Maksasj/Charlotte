# piano

```datalog
is_a(piano, instrument). @from 2026-11-16T19:24:26 @conf 1 @source teacher:pretrain @uses 2 @last 2026-11-16T20:26:16
has(piano, key). @from 2026-11-16T19:26:13 @conf 1 @source teacher:pretrain
```
