# earth

```datalog
proper_name(earth). @from 2026-11-16T19:19:59 @conf 1 @source parser
is_a(earth, planet). @from 2026-11-16T19:21:30 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:21:38
go_around(earth, sun). @from 2026-11-16T19:59:26 @conf 1 @source teacher:pretrain
is_a(earth, planet_number_three). @from 2026-11-16T20:01:18 @conf 1 @source teacher:pretrain
has(earth, life). @from 2026-11-16T20:01:18 @conf 1 @source teacher:pretrain
```
