# pears

```datalog
proper_name(pears). @from 2026-11-16T20:31:24 @conf 1 @source parser
```
