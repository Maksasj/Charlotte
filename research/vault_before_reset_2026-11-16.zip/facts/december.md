# december

```datalog
proper_name(december). @from 2026-11-16T20:57:21 @conf 1 @source parser
```
