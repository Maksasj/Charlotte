# firefighter

```datalog
has(firefighter, hose). @from 2026-11-16T19:16:21 @conf 1 @source teacher:pretrain
```
