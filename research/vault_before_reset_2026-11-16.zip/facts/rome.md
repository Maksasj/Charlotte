# rome

```datalog
proper_name(rome). @from 2026-11-16T19:15:42 @conf 1 @source parser
located_in(rome, italy). @from 2026-11-16T19:15:42 @until 2026-11-16T19:20:48 @conf 1 @source teacher:pretrain
is_a(rome, city_in_italy). @from 2026-11-16T19:20:43 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:47:57
located_in(rome, europe). @from 2026-11-16T19:20:48 @until 2026-11-16T19:20:55 @conf 1 @source teacher:pretrain
located_in(rome, italy). @from 2026-11-16T19:20:55 @until 2026-11-16T19:21:01 @conf 1 @source teacher:pretrain
located_in(rome, europe). @from 2026-11-16T19:21:01 @until 2026-11-16T19:47:57 @conf 1 @source teacher:pretrain
is_a(rome, capital). @from 2026-11-16T19:47:57 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:47:57
located_in(rome, italy). @from 2026-11-16T19:47:57 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:47:57
is_a(rome, city). @from 2026-11-16T19:47:57 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:47:57
property(rome, age, old). @from 2026-11-16T19:47:57 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:47:57
has(rome, ancient_ruin). @from 2026-11-16T19:47:57 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:47:57
has(rome, colosseum). @from 2026-11-16T19:47:57 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T19:47:57
is_a(rome, european_city). @from 2026-11-16T20:31:37 @conf 1 @source teacher:chat
```
