# broth

```datalog
part_of(broth, ramen). @from 2026-11-16T20:28:57 @conf 1 @source teacher:chat
property(broth, quality, cloudy). @from 2026-11-16T20:29:15 @until 2026-11-16T20:32:34 @conf 1 @source teacher:chat
property(broth, quality, rich). @from 2026-11-16T20:29:15 @until 2026-11-16T20:32:34 @conf 1 @source teacher:chat
```
