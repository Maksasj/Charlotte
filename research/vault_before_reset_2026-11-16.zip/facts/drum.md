# drum

```datalog
is_a(drum, instrument). @from 2026-11-16T19:24:31 @conf 1 @source teacher:pretrain @uses 1 @last 2026-11-16T20:26:16
property(drum, sound, boom). @from 2026-11-16T20:26:01 @until 2026-11-16T20:26:01 @conf 1 @source teacher:chat
property(drum, sound, tap). @from 2026-11-16T20:26:01 @until 2026-11-16T20:27:39 @conf 1 @source teacher:chat
make(drum, music). @from 2026-11-16T20:26:16 @conf 1 @source teacher:chat
```
